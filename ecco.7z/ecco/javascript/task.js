function getdata() {
	let data = getTaskData();
	return data;
}
function addTask(data) {
	let output = '<table>';
	$.each(data, function(key, val) {
		output += '<tr><td><b>' + val.name + '</b></td>';
		output += '<td>' + val.date + '</td>';
		output += '<td><b>' + val.assigned + '</b></td></tr>';
	});
	output += '</table>';
	$('#table').html(output);
}
function validateForm() {
	const name = document.forms['task-form']['name'].value;
	if (name === '') {
		alert('Name must be filled out');
		return false;
	}
	const assigned = document.forms['task-form']['assigned'].value;
	if (assigned === '') {
		alert('Assgined name should be filled out');
		return false;
	}
	return true;
}
