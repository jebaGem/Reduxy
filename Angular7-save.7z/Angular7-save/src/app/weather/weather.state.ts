export interface IWeatherState {
	// todo: rename to signatoriesState
	jokes: null;
}
export const initialJokesState: IWeatherState = {
	jokes: null
};
