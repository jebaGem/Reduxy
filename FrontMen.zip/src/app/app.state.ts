import { JokesList } from './front-men-jokes/front-men-jokes.actions';

export interface IRootState {
    frontMenReducer: JokesList;
}

