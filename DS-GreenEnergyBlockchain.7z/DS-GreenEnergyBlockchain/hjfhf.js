(function(n) {
    var f, e;
    if (typeof epi == "undefined" || typeof epi.EPiServer == "undefined" || typeof epi.EPiServer.Forms == "undefined") {
        console.error("Forms is not initialized correctly");
        return
    }
    if (typeof n == "undefined") {
        console.error("Forms cannot work without jQuery");
        return
    }
    f = function(n, i) {
        if (this.workingFormInfo = i.workingFormInfo,
        this.dependantInfo = n,
        this.$domElement = t.getFormElementBlock(n.fieldName, this.workingFormInfo.$workingForm),
        this.onDependencyStateChanged = i.onDependencyStateChanged,
        this.dependency = new epi.EPiServer.Forms.Dependency.Dependant(n,i.workingFormInfo),
        this._registerEventListener(this.dependency),
        this.isSatisfied = this.dependency.isSatisfied,
        typeof this.onDependencyStateChanged == "function")
            this.onDependencyStateChanged(this.$domElement, this.dependantInfo, this.isSatisfied);
        this.check()
    }
    ;
    f.prototype = {
        _registerEventListener: function(t) {
            var i = this;
            n(t).on("change", function(n, t) {
                i.onDependencyChangeHandler.call(i, t)
            })
        },
        onDependencyChangeHandler: function(t) {
            if (this.isSatisfied !== t.isSatisfied) {
                if (this.isSatisfied = t.isSatisfied,
                this._executeAction(),
                typeof this.onDependencyStateChanged == "function")
                    this.onDependencyStateChanged(this.$domElement, this.dependantInfo, this.isSatisfied);
                n(this.$domElement).trigger("formsDependencyStateChanged")
            }
        },
        check: function() {
            this.dependency.runCheck()
        },
        _executeAction: function() {
            if (this.dependantInfo.action) {
                var n = epi.EPiServer.Forms.Dependency.Actions
                  , t = this.dependantInfo.action.clientsideAction;
                n[t] && typeof n[t] == "function" && n[t](this)
            }
        }
    };
    e = function(n, t) {
        this.workingFormInfo = t;
        this.conditions = n.conditions;
        this.conditionCombination = n.conditionCombination;
        this.isSatisfied = null;
        this._registerEventListener()
    }
    ;
    e.prototype = {
        _registerEventListener: function() {
            var i, f, r, u;
            if (this.conditions && !(this.conditions.length <= 0))
                for (i = this,
                f = [],
                r = 0; r < this.conditions.length; r++)
                    if (u = this.conditions[r],
                    f.indexOf(u.fieldName) === -1) {
                        var e = t.getFormElementBlock(u.fieldName, this.workingFormInfo.$workingForm)
                          , h = n("[data-f-datainput]", e)
                          , o = s._getTriggerEventsForDependeeElement(e);
                        o && o.length > 0 && n.each(o, function(n, r) {
                            r !== "change" ? h[r](t.debounce(function(n) {
                                n.stopPropagation();
                                i._handleValueChange()
                            }, epi.EPiServer.Forms.ThrottleTimeout, i)) : h[r](function() {
                                i._handleValueChange.apply(i)
                            })
                        });
                        n(e).on("formsDependencyStateChanged", function() {
                            i._handleValueChange.apply(i)
                        });
                        f.push(u.fieldName)
                    }
        },
        runCheck: function() {
            this._handleValueChange()
        },
        _handleValueChange: function() {
            var t = this.isSatisfied;
            this.isSatisfied = this._checkSatisfaction();
            this.isSatisfied !== t && n(this).trigger("change", {
                isSatisfied: this.isSatisfied
            })
        },
        _checkSatisfaction: function() {
            var n, i;
            if (!this.conditions || this.conditions.length <= 0)
                return !0;
            for (n = 0; n < this.conditions.length; n++) {
                var t = this.conditions[n]
                  , u = this._getFieldState(t.fieldName)
                  , r = epi.EPiServer.Forms.DependConditions[t.operator];
                if (typeof r == "function") {
                    if (i = r(u.value, t.fieldValue),
                    i && this.conditionCombination === epi.EPiServer.Forms.Dependency.ConditionCombinations.Any)
                        return !0;
                    if (!i && this.conditionCombination !== epi.EPiServer.Forms.Dependency.ConditionCombinations.Any)
                        return !1
                }
            }
            return this.conditionCombination === epi.EPiServer.Forms.Dependency.ConditionCombinations.Any ? !1 : !0
        },
        _getFieldState: function(n) {
            var i = t.getFormElementBlock(n, this.workingFormInfo.$workingForm), r;
            return i ? (r = epi.EPiServer.Forms.Dependency._getValueOfDependeeElement(i, this.workingFormInfo),
            {
                value: r
            }) : null
        }
    };
    var t = epi.EPiServer.Forms.Utils
      , i = epi.EPiServer.Forms.Data
      , r = epi.EPiServer.Forms.Extension
      , u = epi.EPiServer.Forms.Validation
      , o = epi.EPiServer.Forms.Navigation
      , s = epi.EPiServer.Forms.Dependency;
    epi.EPiServer.Forms.__DebounceTimer = null;
    epi.EPiServer.Forms.__Initialized = !(epi.EPiServer.Forms.__Initialized === undefined);
    n.extend(!0, epi.EPiServer.Forms, {
        Utils: {
            debounce: function(n, t, i) {
                return function() {
                    var r = this
                      , u = arguments
                      , f = function(n, i, r, u) {
                        clearTimeout(u.__DebounceTimer);
                        u.__DebounceTimer = setTimeout(function() {
                            i.apply(n, r)
                        }, t)
                    };
                    f(r, n, u, i || epi.EPiServer.Forms)
                }
            },
            isInActiveField: function(n, t) {
                return n.DependencyInactiveElements && n.DependencyInactiveElements.indexOf(t) >= 0
            },
            loadExternalScriptOnDemand: function(n, i, r) {
                var o = document.getElementsByTagName("head")[0]
                  , e = 0
                  , s = n.length
                  , f = null
                  , u = null;
                for (t.LoadedScripts = t.LoadedScripts || []; e < s; e++)
                    (f = n[e],
                    t.LoadedScripts.indexOf(f) >= 0) || (u = document.createElement("script"),
                    u.type = "text/javascript",
                    u.async = r || !1,
                    u.defer = r || !1,
                    u.src = f,
                    o.appendChild(u),
                    t.LoadedScripts.push(f));
                u ? t._setupCallback(u, i) : i()
            },
            loadExternalCssOnDemand: function(n, i) {
                for (var o = document.getElementsByTagName("head")[0], u = 0, f = n.length, e = null, r; u < f; u++)
                    e = n[u],
                    r = document.createElement("link"),
                    r.setAttribute("rel", "stylesheet"),
                    r.setAttribute("type", "text/css"),
                    r.setAttribute("href", e),
                    o.appendChild(r),
                    u === f - 1 && t._setupCallback(r, i)
            },
            _setupCallback: function(n, t) {
                typeof t == "function" && (n.onload = t,
                n.onreadystatechange = function() {
                    this.readyState === "complete" && t()
                }
                )
            },
            stringFormat: function(n, t) {
                for (var i = n, r = t.length; r--; )
                    i = i.replace(new RegExp("\\{" + r + "\\}","gm"), t[r] || "");
                return i
            },
            getConcatString: function(n, t) {
                return n instanceof Array ? n.join(t) : n
            },
            htmlEncodeEntities: function(t) {
                return n("<div><\/div>").text(t).html()
            },
            htmlDecodeEntities: function(n) {
                var t = document.createElement("textarea");
                return t.innerHTML = n,
                t.value
            },
            isMatchedReg: function(n, t) {
                try {
                    var r = new RegExp(t)
                      , i = r.exec(n);
                    return i != null && i.length > 0
                } catch (u) {
                    return console.debug(u.message),
                    !1
                }
            },
            raiseFormsEvent: function(t, i) {
                var u = n.extend(!0, {
                    type: "forms",
                    workingFormInfo: t
                }, i), r;
                t ? t.$workingForm.triggerHandler(u) : (r = n('.EPiServerForms:eq(0), [data-f-type="form"]:first'),
                (!r || r.length < 1) && (r = n("body")),
                r.triggerHandler(u))
            },
            injectVisitorData: function(t) {
                var r = n(".FormHidden[data-epiforms-visitordatasources], [data-f-visitordatasources]", t.$workingForm), i;
                r && r.length !== 0 && (i = null,
                r.each(function() {
                    if (i = n(this),
                    i && i.length > 0) {
                        var t = null
                          , r = i.data("epiforms-visitordatasources") || i.data("f-visitordatasources");
                        n(r.split(",")).each(function(n, r) {
                            t = epi.EPiServer.Forms.VisitorData[r];
                            typeof t == "function" && t(i)
                        })
                    }
                }))
            },
            isElementType: function(n, t) {
                return n.data("f-type") === t
            },
            getElementName: function(n) {
                return n.attr("name") || n.data("epiforms-element-name") || n.data("f-element-name")
            },
            getElementValue: function(i) {
                return i.hasClass("FormFileUpload") || t.isElementType(i, "fileupload") ? t.getPreviousPostedFiles(i) : i.hasClass("FormChoice") || t.isElementType(i, "choice") ? i.find(".FormChoice__Input:checked, [data-f-datainput]:checked").map(function(t, i) {
                    return n(i).val()
                }).get() : i.hasClass("FormSelection") || t.isElementType(i, "selection") ? [].concat(i.find("select").val()) : i.hasClass("FormCaptcha") || i.hasClass("FormTextbox") || i.hasClass("FormTextbox--Textarea") || t.isElementType(i, "captcha") || t.isElementType(i, "textbox") ? n.trim(n(".FormTextbox__Input, [data-f-datainput]", i).val()) : i.hasClass("FormRange") || t.isElementType(i, "range") ? n.trim(n(".FormRange__Input, [data-f-datainput]", i).val()) : i.hasClass("Form__CustomElement") || t.isElementType(i, "custom") ? epi.EPiServer.Forms.Extension.getCustomElementValue(i) : t.getNonSpecificElementValue(i)
            },
            getFormStepBlock: function(n, i) {
                return console.warn("This is obsolete. Use getFormElementBlock() instead."),
                t.getFormElementBlock(n, i)
            },
            getFormElementBlock: function(t, i) {
                if (!t)
                    return [];
                var r = n(".Form__Element [data-epiforms-element-name='" + t + "']", i);
                return r && r.length || (r = n("[data-f-element-name='" + t + "']", i)),
                r
            },
            getWorkingFormFromInnerElement: function(t) {
                return n(t).parents(".EPiServerForms:first, [data-f-type='form']:first")
            },
            getFormIdentifier: function(n) {
                return n.prop("id")
            },
            getPreviousPostedFiles: function(i) {
                var r = i.find(".FormFileUpload__Input, [data-f-datainput]")
                  , f = t.getElementName(r)
                  , e = t.getWorkingFormFromInnerElement(r)
                  , o = epi.EPiServer.Forms.Utils.getFormIdentifier(e)
                  , s = epi.EPiServer.Forms.Data.loadFormDataFromStorage(o)
                  , u = r[0].files;
                return n.each(s, function(n, t) {
                    if (n.indexOf("__TempData") != -1 && n.replace("__TempData", "") == f && u.length == 0)
                        return u = t,
                        !1
                }),
                u
            },
            getNonSpecificElementValue: function(t) {
                var i, r;
                return t.attr("data-f-element-name") ? (i = t.find(":input"),
                i.length == 0) ? n.trim(t.val()) : i[0].tagName.toLowerCase() != "input" ? n.trim(n(i[0]).val()) : (r = i[0].type.toLowerCase(),
                r == "checkbox" || r == "radio") ? i.filter(":checked").map(function(t, i) {
                    return n(i).val()
                }).get() : n.trim(n(i[0]).val()) : n.trim(t.val())
            },
            getCurrentStepIndex: function(t) {
                var i = n("input[name=__FormCurrentStepIndex]", t.$workingForm).val();
                return i === undefined || i.trim() === "" || isNaN(+i) || +i > t.StepsInfo.Steps.length - 1 ? t.StepsInfo.AllStepsAreNotLinked ? i = 0 : n.each(t.StepsInfo.Steps, function(n, u) {
                    if (u.attachedContentLink == epi.EPiServer.CurrentPageLink && r.isStepSatisfyDependentCondition(u, t))
                        return i = n,
                        !1
                }) : i = +i,
                i
            },
            setCurrentStepIndex: function(t, i) {
                return n("input[name=__FormCurrentStepIndex]", t.$workingForm).val(i),
                i
            },
            validateRegularExpressionValidator: function(n, i, r) {
                if (!r || !r.model || !r.model.jsPattern || i === "")
                    return {
                        isValid: !0
                    };
                if (!t.isMatchedReg(i, r.model.jsPattern)) {
                    var u = t.stringFormat(r.model.message, [r.model.jsPattern, r.description]);
                    return {
                        isValid: !1,
                        message: u
                    }
                }
                return {
                    isValid: !0
                }
            },
            showNextStepOnEnterKeyDown: function(i) {
                var u = t.getWorkingFormFromInnerElement(i.target)
                  , f = i.keyCode
                  , r = n(".Form__NavigationBar .Form__NavigationBar__Action.btnNext, [data-f-type='navigationbar'] [data-f-navigation-next]", u)
                  , e = n(".Form__Element.FormSubmitButton, [data-f-type='submitbutton']", u).parent(".FormStep, [data-f-type='step']").filter(function() {
                    return !n(this).hasClass("hide")
                });
                return f == 13 && e.length == 0 && r != null && r.length ? (i.preventDefault(),
                i.stopPropagation(),
                r.trigger("click"),
                !0) : !0
            },
            scrollToTheTopOfForm: function(t) {
                t != null && t.css("position").toLowerCase() !== "fixed" && n(document).scrollTop() > 0 && window.scrollTo(0, t.offset().top)
            }
        },
        Extension: {
            getSummarizedText: function(i, r, u) {
                var h = u ? "<br/>" : "\n", y = u ? i.ConfirmMessage : t.htmlDecodeEntities(i.ConfirmMessage), c = i.ElementsInfo, l = [], a = [], p = ["__FormGuid", "__FormLanguage", "__FormCurrentStepIndex", "__FormSubmissionId"], v = i.ConfirmMessage ? y + h + h : "", s = null, f = null, e, o;
                for (e in r)
                    if (l.indexOf(e.replace("__TempData", "")) == -1 && !t.isInActiveField(i, e)) {
                        if (o = e.indexOf("__TempData") !== -1 ? c[e.replace("__TempData", "")] : c[e],
                        s = o && o.friendlyName ? o.friendlyName : "",
                        f = o && o.customBinding == !0 ? epi.EPiServer.Forms.CustomBindingElements[o.type](o, r[e]) : r[e],
                        (f == null || f instanceof Array && f.length === 0 || n.isEmptyObject(f)) && (f = ""),
                        f instanceof Array ? f = n.map(f, function(n) {
                            return n ? typeof n == "string" ? n : typeof n == "object" ? n.name : void 0 : null
                        }).join(", ") : f instanceof FileList && f.length === 0 ? f = "" : (f = f.toString().substr(0, 46).trim(),
                        f.length >= 45 && (f += " ...")),
                        n("[name=" + e + "]", i.$workingForm).hasClass("FormHideInSummarized") && a.push(e),
                        s == "" || s == null || f == "" || f == null || p.indexOf(e) >= 0 || a.indexOf(e) >= 0)
                            continue;
                        else
                            l.push(e);
                        v += u ? t.stringFormat("{0}: {1}" + h, [t.htmlEncodeEntities(s), t.htmlEncodeEntities(f)]) : t.stringFormat("{0}: {1}" + h, [t.htmlDecodeEntities(s), f])
                    }
                return v
            },
            showSummarizedText: function(t, i) {
                var r = n.Deferred(), u = this.getSummarizedText(i, t, !1), f;
                return !u || u.trim() === "" ? (r.resolve(!0),
                r.promise()) : (f = confirm(u),
                r.resolve(f),
                r.promise())
            },
            getCustomElementValue: function(n) {
                return n.val() || n.find("[data-f-datainput]").val()
            },
            bindCustomElementValue: function(n, t) {
                var i = n.find(".Form__CustomInput, [data-f-datainput]");
                i.val(t)
            },
            resetCustomElementValue: function(n) {
                var t = n.find(".Form__CustomInput, [data-f-datainput]");
                t.val("")
            },
            getAllDataElements: function(t) {
                return n(".Form__Element, .Form__CustomElement, [data-f-type]", t).not(".FormStep,.FormSubmitButton,.Form__Element--NonData,[data-f-type='step'],[data-f-type='form'],[data-f-type='resetbutton'],[data-f-type='submitbutton'],[data-f-element-nondata]")
            },
            isStepSatisfyDependentCondition: function(n, t) {
                if (!n)
                    return !1;
                var r = n.dependField
                  , u = i.loadFormDataFromStorage(t.Id)
                  , f = epi.EPiServer.Forms.DependConditions[n.dependCondition];
                return !r || !f || !u ? !0 : f(u[r], n.dependValue)
            },
            getAntiForgeryToken: function(t) {
                var i = n('input[name="__RequestVerificationToken"]', t.$workingForm).val();
                return {
                    antiForgeryToken: i
                }
            },
            buildSubmitRequestHeader: function(t) {
                var i = {}
                  , r = this.getAntiForgeryToken(t);
                return n.extend(i, r),
                i
            }
        },
        Data: {
            loadCurrentFormDataFromStorage: function(n) {
                var t = epi.EPiServer.Forms.Utils.getFormIdentifier(n);
                return this.loadFormDataFromStorage(t)
            },
            loadFormDataFromStorage: function(t) {
                var r = this.getStorage()
                  , i = r[t];
                return i ? (i = n.parseJSON(i),
                !i) ? {} : i : {}
            },
            saveCurrentFormDataToStorage: function(n, t) {
                var i = epi.EPiServer.Forms.Utils.getFormIdentifier(n);
                return this.saveFormDataToStorage(i, t)
            },
            saveFormDataToStorage: function(n, t) {
                var i = this.getStorage();
                try {
                    i.setItem(n, JSON.stringify(t))
                } catch (r) {
                    console.log("Local Storage not supported: " + r.message)
                }
                return t
            },
            clearFormDataInStorage: function(n) {
                removeFormDataInStorage(epi.EPiServer.Forms.Utils.getFormIdentifier(n))
            },
            removeFormDataInStorage: function(n) {
                this.getStorage().removeItem(n)
            },
            getStorage: function() {
                return sessionStorage
            }
        },
        Validation: {
            getValidatorByValidatorType: function(n, t) {
                if (n instanceof Array && n.length !== 0 && t)
                    for (var r = 0, i = null, u = n.length; r < u; r++)
                        if ((i = n[r],
                        i) && i.type === t)
                            return i
            },
            getElementValidators: function(n, t) {
                if (n instanceof Array && n.length !== 0 && t)
                    for (var r = 0, u = n.length, i = null; r < u; r++)
                        if ((i = n[r],
                        i) && (i.targetElementId === t || i.targetElementName === t))
                            return i.validators
            },
            validateFormValue: function(t, i, r) {
                var u = [];
                return n(r).each(function(r, f) {
                    var e = epi.EPiServer.Forms.Validators[f.type], o = null, s;
                    typeof e == "function" ? o = e : typeof e.validate == "function" && (o = e.validate);
                    o && (s = o(t, i, f),
                    n.extend(s, {
                        fieldName: t,
                        fieldValue: i
                    }),
                    u.push(s))
                }),
                u
            }
        },
        Dependency: {
            ConditionCombinations: {
                All: "All",
                Any: "Any"
            },
            Actions: {
                Config: {
                    ShowDuration: 10,
                    HideDuration: 10
                },
                show: function(n) {
                    if (n.isSatisfied) {
                        n.$domElement.show(this.Config.ShowDuration);
                        var t = n.workingFormInfo.DependencyInactiveElements && n.workingFormInfo.DependencyInactiveElements.indexOf(n.dependantInfo.fieldName);
                        t >= 0 && n.workingFormInfo.DependencyInactiveElements.splice(t, 1)
                    } else
                        n.$domElement.hide(this.Config.HideDuration),
                        n.workingFormInfo.DependencyInactiveElements.push(n.dependantInfo.fieldName)
                },
                hide: function(n) {
                    if (n.isSatisfied)
                        n.$domElement.hide(this.Config.HideDuration),
                        n.workingFormInfo.DependencyInactiveElements.push(n.dependantInfo.fieldName);
                    else {
                        n.$domElement.show(this.Config.ShowDuration);
                        var t = n.workingFormInfo.DependencyInactiveElements && n.workingFormInfo.DependencyInactiveElements.indexOf(n.dependantInfo.fieldName);
                        t >= 0 && n.workingFormInfo.DependencyInactiveElements.splice(t, 1)
                    }
                }
            },
            DependantController: f,
            Dependant: e,
            _initDependencyInfos: function(n) {
                var i = n.DependenciesInfo, r;
                if (i && !(i.length <= 0))
                    for (n.DependantControllers = [],
                    r = 0; r < i.length; r++) {
                        var u = i[r]
                          , f = {
                            onDependencyStateChanged: function(i, r, u) {
                                t.raiseFormsEvent(n, {
                                    type: "formsDependencyStateChanged",
                                    targetElement: i,
                                    dependencyInfo: r,
                                    isConditionSatisfied: u
                                })
                            },
                            workingFormInfo: n
                        }
                          , e = new epi.EPiServer.Forms.Dependency.DependantController(u,f);
                        n.DependantControllers.push(e)
                    }
            },
            _getValueOfDependeeElement: function(i, r) {
                var u, f;
                if (!r || !i || (u = t.getElementName(i),
                r.DependencyInactiveElements.indexOf(u) >= 0))
                    return undefined;
                var e = t.getCurrentStepIndex(r)
                  , o = n(r.$steps[e])
                  , s = n(i, o).length > 0;
                return s ? t.getElementValue(i) : (f = epi.EPiServer.Forms.Data.loadCurrentFormDataFromStorage(r.$workingForm),
                f[u])
            },
            _getTriggerEventForDependeeElement: function(n) {
                return t.isElementType(n, "textbox") ? "keyup" : "change"
            },
            _getTriggerEventsForDependeeElement: function(n) {
                return t.isElementType(n, "textbox") ? n.attr("data-f-modifier") === "number" ? ["keyup", "change"] : ["keyup"] : ["change"]
            }
        },
        Navigation: {
            findNextStep: function(n, t) {
                var r = null
                  , u = n + 1
                  , i = t.StepsInfo.Steps[u];
                return i && (r = epi.EPiServer.Forms.Extension.isStepSatisfyDependentCondition(i, t) ? i : this.findNextStep(u, t)),
                r
            },
            findPreviousStep: function(n, t) {
                var r = null
                  , u = n - 1
                  , i = t.StepsInfo.Steps[u];
                return i && (r = epi.EPiServer.Forms.Extension.isStepSatisfyDependentCondition(i, t) ? i : this.findPreviousStep(u, t)),
                r
            }
        }
    });
    var h = i.getStorage()
      , c = {
        VisitorData: {
            "EPiServer.Forms.Implementation.VisitorData.GeoVisitorDataSource": function(t) {
                n.ajax({
                    url: "/EPiServer.Forms/DataSubmit/GetGeoData",
                    type: "GET",
                    success: function(n) {
                        var r = t.val(), i;
                        r || (i = t.data("epiforms-visitordataproperty") || t.data("f-visitordataproperty"),
                        n != null && n[i] && t.val(n[i]))
                    }
                })
            }
        }
    }
      , l = {
        Validators: {
            "EPiServer.Forms.Implementation.Validation.RequiredValidator": function(n, t, i) {
                return i && (t == "" || t && !t.length) ? {
                    isValid: !1,
                    message: i.model.message
                } : {
                    isValid: !0
                }
            },
            "EPiServer.Forms.Implementation.Validation.RegularExpressionValidator": t.validateRegularExpressionValidator,
            "EPiServer.Forms.Implementation.Validation.EmailValidator": t.validateRegularExpressionValidator,
            "EPiServer.Forms.Implementation.Validation.UrlValidator": t.validateRegularExpressionValidator,
            "EPiServer.Forms.Implementation.Validation.DateDDMMYYYYValidator": t.validateRegularExpressionValidator,
            "EPiServer.Forms.Implementation.Validation.DateMMDDYYYYValidator": t.validateRegularExpressionValidator,
            "EPiServer.Forms.Implementation.Validation.DateYYYYMMDDValidator": t.validateRegularExpressionValidator,
            "EPiServer.Forms.Implementation.Validation.IntegerValidator": t.validateRegularExpressionValidator,
            "EPiServer.Forms.Implementation.Validation.PositiveIntegerValidator": t.validateRegularExpressionValidator,
            "EPiServer.Forms.Implementation.Validation.AllowedExtensionsValidator": function(n, t, i) {
                function h(n, t, i) {
                    var r = c(n);
                    return r.length < 1 ? !1 : (r = r.toLowerCase(),
                    t.indexOf(r) >= 0) ? !1 : i.length < 1 ? !0 : i.indexOf(r) > -1
                }
                function c(n) {
                    return n.substr((~-n.lastIndexOf(".") >>> 0) + 2)
                }
                if (!t || t instanceof Array && t.length == 0)
                    return {
                        isValid: !0
                    };
                var o = t
                  , r = i.model.accept
                  , l = epi.EPiServer.Forms.UploadExtensionBlackList.split(",")
                  , u = r == undefined || r.length < 1 ? [] : r.split(",")
                  , f = 0
                  , e = 0
                  , s = u.length
                  , a = o.length;
                if (s > 0)
                    for (; f < s; f++)
                        u[f] = u[f].substr(1);
                for (; e < a; e++)
                    if (!h(o[e].name, l, u))
                        return {
                            isValid: !1,
                            message: epi.EPiServer.Forms.Utils.stringFormat(i.model.message, [r])
                        };
                return {
                    isValid: !0
                }
            },
            "EPiServer.Forms.Implementation.Validation.MaxFileSizeValidator": function(n, t, i) {
                for (var u = t, r = 0, e = u.length, f = i.model.sizeInBytes; r < e; r++)
                    if (u[r].size > f)
                        return {
                            isValid: !1,
                            message: epi.EPiServer.Forms.Utils.stringFormat(i.model.message, [f / 1048576])
                        };
                return {
                    isValid: !0
                }
            },
            "EPiServer.Forms.Implementation.Validation.NumericValidator": function(t, i, r) {
                return !i || n.isNumeric(i) == !0 ? {
                    isValid: !0
                } : {
                    isValid: !1,
                    message: r.model.message
                }
            },
            "EPiServer.Forms.Implementation.Validation.CaptchaValidator": {
                initialize: function(t) {
                    var i = this;
                    t.parents(".FormCaptcha, [data-f-type='captcha']").find(".FormCaptcha__Refresh, [data-f-captcha-refresh]").on("click", function(t) {
                        i._refreshCaptcha(n(this));
                        t.preventDefault()
                    })
                },
                validate: function(n, t) {
                    var i = t.trim();
                    return i != null && i != ""
                },
                onServerValidateFailed: function(n) {
                    this._refreshCaptcha(n);
                    n.focus()
                },
                _refreshCaptcha: function(n) {
                    var i = n.hasClass("FormCaptcha") || t.isElementType(n, "captcha") ? n : n.parents(".FormCaptcha, [data-f-type='captcha']")
                      , r = i.find(".FormCaptcha__Image, [data-f-captcha-image]")
                      , u = i.find(".FormTextbox__Input, [data-f-datainput]");
                    r.attr("src", r.attr("src") + "&d=" + Math.random());
                    u.val("")
                }
            }
        }
    }
      , a = {
        DependConditions: {
            Equals: function(n, t) {
                return n = n ? epi.EPiServer.Forms.Utils.getConcatString(n, ",").toUpperCase() : "",
                t = t ? t.toUpperCase() : "",
                n === t
            },
            NotEquals: function(n, t) {
                return n = n ? epi.EPiServer.Forms.Utils.getConcatString(n, ",").toUpperCase() : "",
                t = t ? t.toUpperCase() : "",
                n != t
            },
            Contains: function(n, t) {
                return n = n ? epi.EPiServer.Forms.Utils.getConcatString(n, ",").toUpperCase() : "",
                t = t ? t.toUpperCase() : "",
                n.indexOf(t) >= 0
            },
            NotContains: function(n, t) {
                return n = n ? epi.EPiServer.Forms.Utils.getConcatString(n, ",") : "",
                !n && t || n && !t || n && t && n.toUpperCase().indexOf(t.toUpperCase()) < 0
            },
            MatchRegularExpression: function(n, t) {
                var i = new RegExp(t,"igm");
                return i.ignoreCase = i.global = i.multiline = !0,
                !t || t && i.test(n)
            }
        }
    };
    n.extend(!0, epi.EPiServer.Forms, c);
    n.extend(!0, epi.EPiServer.Forms, l);
    n.extend(!0, epi.EPiServer.Forms, a);
    n.extend(!0, epi.EPiServer.Forms, {
        CustomBindingElements: {}
    });
    epi.EPiServer.Forms.init = function() {
        epi.EPiServer.Forms.__Initialized || (epi.EPiServer.Forms.__Initialized = !0,
        n(document).ready(function() {
            function y(i) {
                var o, r, s, h;
                if (i.preventDefault(),
                i.stopPropagation(),
                o = t.getWorkingFormFromInnerElement(i.target),
                r = e(o),
                r.SubmittableStatus.submittable === !1)
                    return f(r, r.SubmittableStatus.message),
                    !1;
                if (s = c(r),
                !nt(s, r))
                    return l(s),
                    tt(s),
                    !1;
                h = et(o);
                n.when(ut(r, h)).then(function(e) {
                    var c, l, s, v, a, y;
                    if (!e)
                        return !1;
                    c = [];
                    l = null;
                    for (s in h)
                        s.indexOf("__TempData") == -1 && (r.DependencyInactiveElements.indexOf(s) >= 0 || (l = t.getFormElementBlock(s, o),
                        l.parents(".FormStep:first, [data-f-type='step']:first").hasClass("hide") || (v = u.getElementValidators(r.ValidationInfo, s),
                        c = c.concat(u.validateFormValue(s, h[s], v)))));
                    if (a = n.grep(c, function(n) {
                        return n.isValid == !1
                    }),
                    a.length > 0)
                        return y = n.map(a, function(n) {
                            return r.ElementsInfo[n.fieldName].friendlyName + ": " + n.message
                        }),
                        f(r, y.join(" ")),
                        !1;
                    b(i)
                })
            }
            function p(n) {
                n.preventDefault();
                n.stopPropagation();
                var r = t.getWorkingFormFromInnerElement(n.target)
                  , i = e(r);
                t.raiseFormsEvent(i, {
                    type: "formsReset",
                    sourceEvent: n
                });
                w(r, i);
                s(i.StepsInfo.Steps[0], i)
            }
            function w(u, e) {
                if (u.get(0).reset(),
                e.SubmittableStatus && e.SubmittableStatus.submittable === !1 ? f(e, e.SubmittableStatus.message) : f(e, ""),
                i.removeFormDataInStorage(e.Id),
                r.getAllDataElements(u).each(function(i, u) {
                    var f = n(u);
                    a(f).text("");
                    f.hasClass("FormChoice") || t.isElementType(f, "choice") ? f.find("input[type=checkbox], input[type=radio]").each(function(t, i) {
                        var r = n(i);
                        r.prop("checked", r.data("epiforms-default-value") || r.data("f-default-value") ? !0 : !1)
                    }) : f.hasClass("FormSelection") || t.isElementType(f, "selection") ? (f.find("option[disabled]:eq(0)").prop("selected", !0),
                    f.find("option").each(function(t, i) {
                        var r = n(i);
                        r.prop("disabled") === !1 && r.prop("selected", r.data("epiforms-default-value") || r.data("f-default-value") ? !0 : !1)
                    })) : f.hasClass("FormFileUpload") || t.isElementType(f, "fileupload") ? (k(f).text(""),
                    it(f.find(".FormFileUpload__Input, [data-f-datainput]"))) : (f.hasClass("Form__CustomElement") || t.isElementType(f, "custom")) && r.resetCustomElementValue(f)
                }),
                e.DependantControllers && e.DependantControllers.length)
                    for (var o = 0; o < e.DependantControllers.length; o++)
                        e.DependantControllers[o].check()
            }
            function b(u) {
                var p = t.getWorkingFormFromInnerElement(u.target), vt = epi.EPiServer.Forms.Utils.getFormIdentifier(p), h = e(p), yt = c(h), a = n(u.srcElement || u.currentTarget).closest("[data-f-type='submitbutton']"), ht = !!a.data("epiforms-is-progressive-submit") || !!a.data("f-is-progressive-submit"), ft, ct, y, b, et, ot, st, nt;
                if (a.data("f-type") !== "submitbutton" || (ft = yt.find("[data-f-type=submitbutton]")[0],
                !ft || (ct = n(ft).attr("data-f-element-name"),
                !t.isInActiveField(h, ct)))) {
                    var tt = i.saveFormDataToStorage(h.Id, d(p))
                      , l = new FormData
                      , ut = t.getCurrentStepIndex(h)
                      , k = o.findNextStep(ut, h)
                      , lt = h.StepsInfo.Steps.length
                      , at = ut === lt - 1
                      , g = k ? !1 : at;
                    k || at || (k = h.StepsInfo.Steps[lt - 1]);
                    g = g || !!a.data("epiforms-is-finalized") || !!a.data("f-is-finalized");
                    tt[a.prop("name")] = a.val();
                    l.append("__FormGuid", vt);
                    l.append("__FormHostedPage", epi.EPiServer.CurrentPageLink);
                    l.append("__FormLanguage", epi.EPiServer.CurrentFormLanguage);
                    l.append("__FormCurrentStepIndex", ut);
                    l.append("__FormWithJavaScriptSupport", "true");
                    for (b in tt)
                        if (tt.hasOwnProperty(b) && !t.isInActiveField(h, b))
                            if (y = tt[b],
                            Array.isArray(y) && y.length > 0 && y[0] !== null && typeof y[0] == "object" && y[0].file && Object.getPrototypeOf(y[0].file) === File.prototype) {
                                for (et = y,
                                ot = "",
                                nt = 0; nt < et.length; nt++)
                                    st = et[nt].file,
                                    l.append(b + "_file_" + nt, st),
                                    ot += st.name + "|";
                                l.append(b, ot)
                            } else
                                l.append(b, y);
                    t.raiseFormsEvent(h, {
                        type: "formsStartSubmitting",
                        formData: l
                    });
                    a.prop("disabled", !0);
                    f(h, "");
                    n.ajax({
                        url: h.DataSubmitController + "/Submit",
                        headers: r.buildSubmitRequestHeader(h),
                        data: l,
                        cache: !1,
                        type: p.prop("method"),
                        processData: !1,
                        contentType: !1,
                        async: epi.EPiServer.Forms.AsyncSubmit || p.data("epiforms-async-submit") || p.data("f-async-submit") || !1,
                        success: function(r) {
                            var o, a, y, e;
                            if (u.preventDefault(),
                            n(".Form__Element__ValidationError, [data-f-validationerror]").text(""),
                            r.IsSuccess === !0) {
                                if (o = c(h),
                                n(".FormFileUpload .FormFileUpload__Input, [data-f-type='fileupload'] [data-f-datainput]", o).each(function() {
                                    n(this).val("");
                                    it(n(this))
                                }),
                                g == !1 && ht == !1)
                                    return t.raiseFormsEvent(h, {
                                        type: "formsNavigationNextStep",
                                        targetStep: k
                                    }),
                                    a = i.loadFormDataFromStorage(h.Id),
                                    y = n.extend(a, {
                                        __FormSubmissionId: r.Data.SubmissionId
                                    }),
                                    i.saveFormDataToStorage(h.Id, y),
                                    t.raiseFormsEvent(h, {
                                        type: "formsSubmitted",
                                        formData: l,
                                        isFinalizedSubmission: !1,
                                        isSuccess: r.IsSuccess,
                                        returnedResult: r
                                    }),
                                    s(k, h),
                                    !1;
                                if (g == !0 && w(p, h),
                                t.raiseFormsEvent(h, {
                                    type: "formsSubmitted",
                                    formData: l,
                                    isFinalizedSubmission: g,
                                    isSuccess: r.IsSuccess,
                                    returnedResult: r
                                }),
                                e = h.StepsInfo.Steps.length,
                                r.RedirectUrl)
                                    return window.location.href = r.RedirectUrl,
                                    !1;
                                ht == !1 && !k && ut < e - 1 ? s(h.StepsInfo.Steps[e - 1], h) : (n(".Form__MainBody, [data-f-mainbody]", h.$workingForm).hide(),
                                f(h, r.Message, !0))
                            } else
                                v(h),
                                t.raiseFormsEvent(h, {
                                    type: "formsSubmitted",
                                    formData: l,
                                    isSuccess: r.IsSuccess,
                                    returnedResult: r
                                }),
                                r.Message && f(h, r.Message),
                                r.Data && r.Data.ValidationInfo && r.Data.ValidationInfo.length > 0 && rt(h, r.Data.ValidationInfo)
                        },
                        error: function(n, i, r) {
                            u.preventDefault();
                            t.raiseFormsEvent(h, {
                                type: "formsSubmittedError",
                                formData: l,
                                isSuccess: !1,
                                xhr: n,
                                typeOfFailure: i,
                                status: r
                            });
                            f(h, i + " " + n.status + ": " + r)
                        },
                        complete: function() {
                            a.prop("disabled", !1);
                            v(h)
                        }
                    })
                }
            }
            function rt(t, i) {
                for (var s, e, f = null, r = 0; r < i.length; r++)
                    if (i[r] && i[r].InvalidElement) {
                        f = n("#" + i[r].InvalidElement + "", t.$workingForm);
                        var h = a(f)
                          , c = u.getElementValidators(t.ValidationInfo, i[r].InvalidElement)
                          , o = u.getValidatorByValidatorType(c, i[r].Validator);
                        o && (s = epi.EPiServer.Forms.Validators[o.type],
                        e = s.onServerValidateFailed,
                        e && typeof e == "function" && e.apply(s, [f, o]));
                        h.text(i[r].ValidationMessage || epi.EPiServer.Forms.Messages.viewMode.commonValidationFail).show()
                    }
                f && l(f.parents(".FormStep:first, [data-f-type='step']:first"))
            }
            function ut(t, i) {
                var u = n.Deferred(), f, e;
                return t.ShowSummarizedData ? (f = [],
                e = ["__FormGuid", "__FormLanguage", "__FormCurrentStepIndex", "__FormSubmissionId"],
                r.showSummarizedText(i, t, e, f)) : (u.resolve(!0),
                u.promise())
            }
            function f(t, i, r) {
                if (t) {
                    var u = n(".Form__Status__Message, [data-f-form-statusmessage]", t.$workingForm);
                    u.removeClass("Form__Warning__Message").removeClass("Form__Success__Message");
                    r == !0 && i ? u.removeClass("hide").addClass("Form__Success__Message").html(i) : i ? u.removeClass("hide").addClass("Form__Warning__Message").html(i) : u.addClass("hide").html("")
                }
            }
            function ft(i, u) {
                n.each(i, function(i, f) {
                    var h = i.indexOf("__TempData") != -1 ? i.replace("__TempData", "") : i, e = n('[data-epiforms-element-name="' + h + '"], [data-f-element-name="' + h + '"]', u), o, c, s, l, a, v;
                    if (e.length != 0) {
                        if (e.hasClass("FormExcludeDataRebind") || !!e.data("f-excludedatarebind"))
                            return;
                        if (o = e.find(".FormChoice__Input--Checkbox, [data-f-datainput]:checkbox"),
                        o.length != 0) {
                            n.each(o, function() {
                                var t = n(this).val();
                                n(this).attr("checked", f.indexOf(t) > -1)
                            });
                            return
                        }
                        if (o = e.find(".FormChoice__Input--Radio, [data-f-datainput]:radio"),
                        o.length != 0) {
                            c = n.isArray(f) ? f[0] : f;
                            n.each(o, function() {
                                var t = n(this).val();
                                n(this).attr("checked", c == t)
                            });
                            return
                        }
                        if (e.hasClass("FormSelection") || t.isElementType(e, "selection")) {
                            n("option:enabled", e).each(function(t, i) {
                                n(i).attr("selected", f.indexOf(n(i).val()) > -1)
                            });
                            return
                        }
                        if (e.hasClass("FormCaptcha") || t.isElementType(e, "captcha"))
                            return;
                        if (o = e.find(".FormFileUpload__Input, [data-f-datainput]:file"),
                        o.length != 0) {
                            s = "";
                            f instanceof Array && f.length > 0 && (l = f.map(function(n) {
                                return n.name
                            }).join(", "),
                            s = s.concat(l));
                            s !== "" && (a = t.stringFormat(epi.EPiServer.Forms.Messages.fileUpload.postedFile, [s]),
                            v = k(e),
                            v.text(a).show());
                            return
                        }
                        if (e.hasClass("Form__CustomElement") || t.isElementType(e, "custom")) {
                            r.bindCustomElementValue(e, f);
                            return
                        }
                        e.find("[data-f-datainput]:first").val(f)
                    }
                })
            }
            function k(n) {
                return n.find(".FormFileUpload__PostedFile, [data-f-postedFile]")
            }
            function d(t, r) {
                var u = e(t)
                  , f = c(u)
                  , o = g(f, r)
                  , s = i.loadFormDataFromStorage(u.Id);
                return n.extend(s, o)
            }
            function et(t) {
                var r = e(t)
                  , u = g(t)
                  , f = i.loadFormDataFromStorage(r.Id);
                return n.extend(f, u)
            }
            function e(n) {
                var r = t.getFormIdentifier(n)
                  , i = epi.EPiServer.Forms[r];
                return i.$workingForm = n,
                i
            }
            function g(i, u) {
                var f = {};
                return r.getAllDataElements(i).each(function(i, r) {
                    var e = n(r), o, s, h, a, c, l;
                    if ((typeof u != "function" || !u(e)) && !e.parents(".FormStep:first, [data-f-type='step']:first").hasClass("hide") && (o = t.getElementName(e),
                    o)) {
                        if (e.hasClass("FormFileUpload") || t.isElementType(e, "fileupload")) {
                            if (s = n(".FormFileUpload__Input, [data-f-datainput]", e)[0],
                            h = o + "__TempData",
                            f[o] = [],
                            f[h] = [],
                            s && s.files.length !== 0)
                                for (c = 0; c < s.files.length; c++)
                                    l = s.files[c],
                                    f[o].push({
                                        name: l.name,
                                        file: l
                                    }),
                                    f[h].push({
                                        name: l.name
                                    });
                            else
                                a = t.getPreviousPostedFiles(e),
                                f[o] = a,
                                f[h] = a;
                            return
                        }
                        f[o] = t.getElementValue(e)
                    }
                }),
                f
            }
            function nt(n, i) {
                if (!n)
                    return !0;
                var u = !0;
                return r.getAllDataElements(n).each(function(n, t) {
                    u = ot(t, i) && u
                }),
                t.raiseFormsEvent(i, {
                    type: "formsStepValidating",
                    isValid: u
                }),
                i.$workingForm.toggleClass("ValidationSuccess", u),
                i.$workingForm.toggleClass("ValidationFail", !u),
                u
            }
            function ot(i, r) {
                var f = n(i), h = a(f), e = t.getElementName(f), v = f.attr("id") || e, c = u.getElementValidators(r.ValidationInfo, v), o = !0, l, y, s, p;
                return f.removeClass("ValidationFail ValidationSuccess"),
                h.hide(),
                l = t.getElementValue(f),
                r.DependencyInactiveElements.indexOf(e) < 0 && c instanceof Array && c.length > 0 && (y = u.validateFormValue(e, l, c),
                s = n.grep(y, function(n) {
                    return n.isValid == !1
                }),
                s && s.length > 0 ? (p = n.map(s, function(n) {
                    return n.message
                }),
                f.addClass("ValidationFail"),
                h.text(p.join(" ")).show(),
                o = !1) : (f.addClass("ValidationSuccess"),
                o = !0)),
                t.raiseFormsEvent(r, {
                    type: "elementValidated",
                    isValid: o,
                    elementName: e,
                    elementValue: l,
                    elementIdentifier: v,
                    element: i,
                    $messageContainer: h
                }),
                o
            }
            function a(i) {
                var r = t.getElementName(i)
                  , u = t.stringFormat("{0}[data-epiforms-linked-name='{1}'], {0}[data-epiforms-linked-name='{2}']", [".Form__Element__ValidationError", r, i.attr("id")])
                  , f = t.stringFormat("{0}[data-f-linked-name='{1}'], {0}[data-f-linked-name='{2}']", ["[data-f-validationerror]", r, i.attr("id")]);
                return n(u).add(f)
            }
            function st(r) {
                if (r && r.StepsInfo && r.StepsInfo.Steps && (r.$steps = n(".FormStep, [data-f-type='step']", r.$workingForm),
                !(r.StepsInfo.Steps.length < 2))) {
                    var u = r.StepsInfo.Steps[t.getCurrentStepIndex(r)];
                    s(u, r);
                    n(".Form__NavigationBar__Action.btnNext, [data-f-navigation-next]", r.$workingForm).on("click", function(n) {
                        n.preventDefault();
                        var t = c(r)
                          , i = nt(t, r);
                        if (!i)
                            return l(t),
                            tt(t),
                            !1;
                        b(n)
                    });
                    n(".Form__NavigationBar__Action.btnPrev, [data-f-navigation-previous]", r.$workingForm).on("click", function(u) {
                        var e, f, h;
                        u.preventDefault();
                        e = d(r.$workingForm, function(n) {
                            return n.hasClass("FormFileUpload") || t.isElementType(n, "fileupload")
                        });
                        i.saveFormDataToStorage(r.Id, e);
                        f = o.findPreviousStep(t.getCurrentStepIndex(r), r);
                        s(f, r);
                        h = n("section[data-epiforms-stepindex=" + f.index + "], section[data-f-stepindex=" + f.index + "]", r.$workingForm);
                        l(h);
                        t.raiseFormsEvent(r, {
                            type: "formsNavigationPrevStep",
                            targetStep: f
                        })
                    })
                }
            }
            function s(r, u) {
                if (r) {
                    t.raiseFormsEvent(u, {
                        type: "formsNavigateToStep",
                        targetStep: r
                    });
                    var e = i.loadFormDataFromStorage(u.Id);
                    if (ft(e, u.$workingForm),
                    u.StepsInfo.AllStepsAreNotLinked || r.attachedContentLink == epi.EPiServer.CurrentPageLink)
                        u.$steps.addClass("hide"),
                        u.$steps.each(function(i, f) {
                            if (i === r.index)
                                return n(f).removeClass("hide"),
                                t.setCurrentStepIndex(u, r.index),
                                !1
                        }),
                        t.scrollToTheTopOfForm(u.$workingForm);
                    else {
                        if (r.attachedUrl && r.attachedUrl.length) {
                            window.location.replace(r.attachedUrl);
                            return
                        }
                        u.StepsInfo.AllStepsAreNotLinked || f(u, epi.EPiServer.Forms.Messages.viewMode.malformStepConfiguration)
                    }
                } else
                    u.$steps.hide();
                v(u)
            }
            function l(t) {
                epi.EPiServer.Forms.Validators["EPiServer.Forms.Implementation.Validation.CaptchaValidator"]._refreshCaptcha(n(".Form__Element.FormCaptcha, [data-f-type='captcha']", t))
            }
            function tt(t) {
                if (t) {
                    var i = n(".Form__Element.ValidationFail", t)[0];
                    i && (i.scrollIntoView(),
                    n("[data-f-datainput]", i).focus())
                }
            }
            function v(i) {
                var u = t.getCurrentStepIndex(i), r = n(".Form__NavigationBar, [data-f-type='navigationbar']", i.$workingForm), o, s, f, e;
                if (u < 0) {
                    r.hide();
                    return
                }
                o = n(".Form__NavigationBar__Action.btnPrev, [data-f-navigation-previous]", r).prop("disabled", !1);
                s = n(".Form__NavigationBar__Action.btnNext, [data-f-navigation-next]", r).prop("disabled", !1);
                (u == 0 || i.SubmittableStatus.submittable === !1) && o.prop("disabled", !0);
                (u == i.StepsInfo.Steps.length - 1 || i.SubmittableStatus.submittable === !1) && s.prop("disabled", !0);
                n(".Form__NavigationBar, [data-f-type='navigationbar']", i.$workingForm).toggle(i.ShowNavigationBar);
                f = u + 1;
                e = i.StepsInfo.Steps.length;
                n(".Form__NavigationBar__ProgressBar__CurrentStep, [data-f-navigation-currentStep]", r).text(f);
                n(".Form__NavigationBar__ProgressBar__StepsCount, [data-f-navigation-stepcount]", r).text(e);
                n(".Form__NavigationBar__ProgressBar--Progress, [data-f-navigation-progress]", r).css({
                    width: 100 * f / e + "%"
                })
            }
            function c(i) {
                var r = t.getCurrentStepIndex(i);
                return n(i.$steps[r])
            }
            function it(n) {
                /MSIE/.test(navigator.userAgent) && n.replaceWith(n = n.clone(!0))
            }
            if (!h) {
                n('.EPiServerForms .Form__Status__Message, [data-f-type="form"] [data-f-form-statusmessage]').text(epi.EPiServer.Forms.ErrorMessages.cantnotworkwithoutstorage);
                return
            }
            n('.EPiServerForms, [data-f-type="form"]').each(function(i, r) {
                var o = n(r)
                  , u = e(o);
                u.SubmittableStatus && u.SubmittableStatus.submittable === !1 && f(u, u.SubmittableStatus.message);
                st(u);
                epi.EPiServer.Forms.Dependency._initDependencyInfos(u);
                n(u.ValidationInfo).each(function(t, i) {
                    n(i.validators).each(function(t, r) {
                        var u = epi.EPiServer.Forms.Validators[r.type];
                        u && typeof u.initialize == "function" && u.initialize(n("#" + i.targetElementId))
                    })
                });
                t.injectVisitorData(u);
                n(".Form__Element.FormSubmitButton, [data-f-type='submitbutton']", o).off("click", y).on("click", y);
                n(".Form__Element.FormResetButton, [data-f-type='resetbutton']", o).off("click", p).on("click", p);
                t.raiseFormsEvent(u, {
                    type: "formsSetupCompleted"
                })
            });
            n(".EPiServerForms .FormTextbox--Number .FormTextbox__Input, [data-f-type='form'][data-f-type='textbox'][data-f-modifier='number'] [data-f-datainput]").on("keydown", function(n) {
                var t = n.which || n.keyCode, i;
                return !n.shiftKey && !n.altKey && !n.ctrlKey && t >= 65 && t <= 90 || t == 32 ? !1 : !n.shiftKey && !n.altKey && !n.ctrlKey && t >= 48 && t <= 57 || t >= 96 && t <= 105 || n.keyCode == 65 && n.ctrlKey === !0 || t == 67 && n.ctrlKey === !0 || t == 88 && n.ctrlKey === !0 || t >= 35 && t <= 39 || t == 8 || t == 9 || t == 13 || t == 46 || t == 45 ? !0 : (i = this.value,
                (t == 109 || t == 189) && i[0] === "-") ? !1 : (!n.shiftKey && !n.altKey && !n.ctrlKey && t == 190 || t == 188 || t == 110) && /[\.,]/.test(i) ? !1 : void 0
            }).on("keyup", function() {
                var n = this.value;
                isNaN(n) && n && (n = (n[0] === "-" ? "-" : "") + n.replace(/[^0-9\.]/g, ""),
                n = n.replace(/\.(?=(.*)\.)+/g, ""),
                this.value = n)
            });
            n('.EPiServerForms input.FormTextbox__Input,.FormChoice__Input.FormChoice__Input--Checkbox,.FormRange__Input,.FormTextbox__Input.FormUrl__Input,.FormChoice__Input.FormChoice__Input--Radio,.FormTextbox__Input.FormCaptcha__Input.FormHideInSummarized,[data-f-type="form"] [data-f-datainput]:not(textarea)').on("keydown", function(n) {
                return t.showNextStepOnEnterKeyDown(n)
            })
        }))
    }
    ;
    epi.EPiServer.Forms.ExternalScriptSources.length <= 0 && epi.EPiServer.Forms.ExternalCssSources.length <= 0 ? epi.EPiServer.Forms.init() : (t.loadExternalScriptOnDemand(epi.EPiServer.Forms.ExternalScriptSources, function() {
        t.raiseFormsEvent(null, {
            type: "formsLoadExternalScripts",
            scripts: epi.EPiServer.Forms.ExternalScriptSources
        });
        epi.EPiServer.Forms.init()
    }),
    t.loadExternalCssOnDemand(epi.EPiServer.Forms.ExternalCssSources, function() {
        t.raiseFormsEvent(null, {
            type: "formsLoadExternalCss",
            Css: epi.EPiServer.Forms.ExternalCssSources
        })
    }))
}
)($$epiforms || $);
