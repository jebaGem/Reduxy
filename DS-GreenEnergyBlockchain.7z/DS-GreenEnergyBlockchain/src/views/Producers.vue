<template>
  <div class="greenenergy-page">
    <h2 class="page-header">{{$options.name}}</h2>
    <b-container fluid class="producer-container">
      <div class="marginTopClass">
        <b-row class="my-1">
          <b-col sm="5" class="left-side-space-border-div">
            <h3>Existing Producers:</h3>
            <b-list-group>
              <b-list-group-item
                v-for="item of productionLocations"
                v-bind:key="item.Id"
                v-bind:class="{ active: item.Id == selectedProductionLocationId }"
                v-on:click="selectedProductionLocationId = item.Id; loadAllocationData()"
                href="#"
              >{{item.Id}}: {{item.Name}}</b-list-group-item>
            </b-list-group>
          </b-col>
          <b-col sm="6" class="green-energy-table">
            <b-table striped hover :items="energyPerPeriod" :fields="energyPerPeriodFields"></b-table>
          </b-col>
        </b-row>
        <b-row>
          <b-col sm="12">
            <h3 class="chart-title">Usage Energy Bank</h3>
            <GChart
              class="green-energy-chart"
              type="ColumnChart"
              :data="chartData"
              :options="chartOptions"
              style="width: 93% !important; height: 600px; margin: 0 0 50px 4%"
            />
          </b-col>
        </b-row>
      </div>
    </b-container>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';

import Web3 from 'web3';
import Web3ObjectProvider from '@/ethereumStuff/Web3ObjectProvider';
import { EventLog } from 'web3/types';
import ContractProvider from '@/ethereumStuff/ContractProvider';

import store from '@/config/Store';

import { ILocation, IEnergyBankEntry, IEnergyPerPeriod } from '@/ethereumStuff/Interfaces';

export default Vue.extend({
  name: 'Producers',
  async mounted() {
    console.log('Mounted');
    this.debugMsg(`Mounted ${this.$options.name}`);
    await this.loadLocations();
    await this.loadAllocationData();
  },
  methods: {
    debugMsg(msg: string) {
      this.$root.$emit('debugMsg', msg);
    },
    async loadLocations() {
      const ctr = await ContractProvider.getGreenEnergyContract();

      this.productionLocations = [];
      const amountOfProdLocs = (await ctr.methods.getProductionLocationsCount().call()) as number;
      for (let i = 0; i < amountOfProdLocs; i++) {
        const locationName = await ctr.methods.getProductionLocationName(i).call();
        this.productionLocations.push({ Id: i, Name: locationName });
      }
    },
    async loadAllocationData() {
      const ctr = await ContractProvider.getGreenEnergyContract();

      const start = 0;
      const end = 10;

      const theEnergyPeriods: IEnergyPerPeriod[] = [];
      const chartData: any[][] = [];

      for (let i = start; i < end; i++) {
        const energyPerPeriodItem: IEnergyPerPeriod = {
          Period: i,
          Bank: 0,
          LightGreen: 0,
          DarkGreen: 0,
        };
        theEnergyPeriods.push(energyPerPeriodItem);
      }

      const wholeBank = await ctr.methods.getWholeEnergyBank(this.selectedProductionLocationId).call();
      for (let i = 0; i < wholeBank.productionDates.length; i++) {
        const bankEntry: IEnergyBankEntry = { Period: parseInt(wholeBank.productionDates[i], 10), Energy: parseInt(wholeBank.quantities[i], 10) };
        theEnergyPeriods[bankEntry.Period].Bank = bankEntry.Energy;
      }

      const allEvents = await ctr.getPastEvents('EnergyTransfered', {
        filter: { productionLocationId: [this.selectedProductionLocationId] },
        fromBlock: 0,
      });

      for (const curEventLog of allEvents) {
        const curPeriod = parseInt(curEventLog.returnValues.productionDate, 10);
        const parsedQuanity = parseInt(curEventLog.returnValues.quantity, 10);

        if (curEventLog.returnValues.transferType === '0') {
          // Dark Green Energy
          theEnergyPeriods[curPeriod].DarkGreen += parsedQuanity;
        } else if (curEventLog.returnValues.transferType === '1') {
          // Light Green Energy
          theEnergyPeriods[curPeriod].LightGreen += parsedQuanity;
        }
      }

      chartData.push(['Period', 'DarkGreen', 'LightGreen', 'Bank']);

      for (const curPeriod of theEnergyPeriods) {
        chartData.push([`${curPeriod.Period}`, curPeriod.DarkGreen, curPeriod.LightGreen, curPeriod.Bank]);
      }

      this.energyPerPeriod = theEnergyPeriods;
      this.chartData = chartData;
    },
  },
  data() {
    return {
      web3: Web3ObjectProvider.getWeb3(),
      productionLocations: [] as ILocation[],
      selectedProductionLocationId: 0,
      energyPerPeriod: [] as IEnergyPerPeriod[],
      energyPerPeriodFields: [{ key: 'Period', sortable: true }, { key: 'DarkGreen', sortable: true }, { key: 'LightGreen', sortable: true }, { key: 'Bank', sortable: true }],
      chartData: [['Period', 'DarkGreen', 'LightGreen', 'Bank'], ['0', 0, 0, 0]],
      chartOptions: {
        chart: {
          title: 'Energy Production',
        },
        series: {
          0: { color: '#0b8d5c' },
          1: { color: '#12c481' },
          2: { color: '#f9a638' },
        },
        isStacked: true,
        animation: {
          duration: 500,
          easing: 'out',
        },
      },
    };
  },
});
</script>

<style scoped lang="scss">
@import '../../src/assets/scss/components/consumerProducer.scss';
</style>


