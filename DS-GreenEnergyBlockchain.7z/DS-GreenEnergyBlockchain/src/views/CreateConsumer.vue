
<template>
  <div>
    <h2 class="page-header">{{$options.name}}</h2>
    <b-container fluid>
        <div class="marginTopClass">
      <b-row class="my-1">
        <b-col sm="6">
        <div class="left-side-space-border-div">

          <b-form class="green-energy-form" @submit="onSubmit" @reset="onReset" v-if="show">
            <b-form-group
              class="producer-section"
              id="consumerNameInputGroup"
              label-for="consumerNameInput"
              vertical
            >
                    <p class="consumerNameLabel">Consumer Name:</p>
              <b-form-input
                id="consumerNameInput"
                type="text"
                v-model="form.consumerName"
                required
                placeholder="Enter Consumer Name"
              ></b-form-input>
              <b-button type="submit" variant="primary">Submit</b-button>
            </b-form-group>
          </b-form>
          </div>
        </b-col>
        <b-col sm="6" class="existing-producer">
          <h3>Existing Consumers:</h3>
          <b-list-group>
            <b-list-group-item
              v-for="item of consumptionLocations"
              v-bind:key="item.Id"
            >{{item.Id}}: {{item.Name}}</b-list-group-item>
          </b-list-group>
        </b-col>
      </b-row>
      </div>
    </b-container>
  </div>
</template>



<script lang="ts">
import Vue from 'vue';

import Web3 from 'web3';
import Web3ObjectProvider from '@/ethereumStuff/Web3ObjectProvider';
import ContractProvider from '@/ethereumStuff/ContractProvider';

import store from '@/config/Store';
import jobsStore from '@/code/JobsStore';
import { SetJobStateArguments, JobState } from '@/code/JobsStore';

import { ILocation } from '@/ethereumStuff/Interfaces';

export default Vue.extend({
  name: 'CreateConsumer',
  async mounted() {
    console.log('Mounted');
    this.debugMsg(`Mounted ${this.$options.name}`);
    await this.loadConsumptionLocations();
  },
  methods: {
    debugMsg(msg: string) {
      this.$root.$emit('debugMsg', msg);
    },
    async loadConsumptionLocations() {
      const ctr = await ContractProvider.getGreenEnergyContract();

      this.consumptionLocations = [];
      const amountOfLocs = await ctr.methods.getConsumptionLocationsCount().call() as number;
      for (let i = 0; i < amountOfLocs; i++) {
        const locationName = await ctr.methods.getConsumptionLocationName(i).call();
        this.consumptionLocations.push({ Id: i, Name: locationName });
      }
    },
    async onSubmit(evt: Event) {
      evt.preventDefault();
      const theJob = await jobsStore.dispatch('addJob', `Creating consumer '${this.form.consumerName}'...`);

      const ctr = await ContractProvider.getGreenEnergyContract();

      await jobsStore.dispatch('setJobState', { Job: theJob, NewState: JobState.Running});

      try {
        const transResult = await ctr.methods.createConsumptionLocation(this.form.consumerName).send();

        await jobsStore.dispatch('setJobState', { Job: theJob, NewState: JobState.Completed});
      } catch (ex) {
        const error = ex.toString();
        this.debugMsg(error);
        const isCancelled = error.endsWith('User denied transaction signature.');
        if (!isCancelled) {
          this.$root.$emit('openDebugBox');
        }
        await jobsStore.dispatch('setJobState', { Job: theJob, NewState: isCancelled ? JobState.Cancelled : JobState.Failed, Reason: isCancelled ? 'Cancelled by used' : 'An error occured during this transaction, see the debug box.'});
      }
      await this.loadConsumptionLocations();
    },
    onReset(evt: Event) {
      evt.preventDefault();
      /* Reset our form values */
      this.form.consumerName = '';

      /* Trick to reset/clear native browser form validation state */
      this.show = false;
      this.$nextTick(() => { this.show = true; });
    },
  },
  data() {
    return {
      web3: Web3ObjectProvider.getWeb3(),
      show: true,
      form: {
        consumerName: '',
      },
      consumptionLocations: [] as ILocation[],
    };
  },
});
</script>

<style scoped lang="scss">
@import "../../src/assets/scss/components/createProducerConsumer.scss";
</style>


