<template>
  <div class="about-page">
    <div class="top-green">
      <router-link
        class="nav-link"
        to="/home/createproducer"
      >Login</router-link>
    </div>
    <img
      class="logo logo-img"
      alt="Vue logo"
      src="../assets/images/logo.svg"
    >
    <h3>Green Energy Blockchain</h3>
    <p class="about-page-text">
      This demo is created to show the strengths of Blockchain in a scenario where green energy is traded between producers and consumers.
      Blockchain provides a tracable and secure way to prove the ownership of the produced energy.</p>
    <p class="about-message-goal">
      The goal is to produce
      and allocate green energy
      through Blockchain
    </p>
    <b-container class="bv-why-block-chain">
      <b-row>
        <b-col class="why-block-chain-img"> <img
            class="logo"
            alt="Vue logo"
            src="../assets/images/whyblkchainimg.png"
          ></b-col>
        <b-col class="why-block-chain-text">
          <h5>
            Why Blockchain?
          </h5>
          <ul>
            <li> Orderlog provable and verifiabe
              (Government can verify all transactions)</li>
            <li>
              Ownership of energy certificates can be proven</li>
          </ul>
        </b-col>
      </b-row>
    </b-container>

    <b-container class="bv-example-row benefits">
      <b-row>
        <b-col class="benefits-farmer">
          <h4>
            Benefits Farmer
          </h4>
          <p>
            The farmer can sell and trade green energy certificates to consumers thus earning more money.
          </p>
        </b-col>
        <b-col class="benefits-consumer">
          <h4>
            Benefits Consumer
          </h4>
          <p>
            Instead of having to buy expensive green energy certificates from energy companies, businesses can now buy them directly from the farmer.
          </p>
        </b-col>
      </b-row>
    </b-container>

    <b-container class="bv-example-row user-tool">
      <h3> User Tool </h3>
      <b-row>
        <b-col><img
            class="logo"
            alt="Vue logo"
            src="../assets/images/boer.svg"
          >
          <h5>Farmer</h5>
          <span>Producer of green energy</span>
        </b-col>
        <b-col><img
            class="logo"
            alt="Vue logo"
            src="../assets/images/consumer.svg"
          >
          <h5>Consumer</h5>
          <span>Companies that consume green energy</span>
        </b-col>
        <b-col><img
            class="logo"
            alt="Vue logo"
            src="../assets/images/system.svg"
          >
          <h5>Computer System</h5>
          <span>Allocates the green energy from producer to consumer</span>
        </b-col>
        <b-col> <img
            class="logo"
            alt="Vue logo"
            src="../assets/images/windmolencompany.svg"
          >
          <h5>Metering Company</h5>
          <span>Measures produced and consumed energy</span>
        </b-col>
      </b-row>
    </b-container>

    <b-container class="bv-example-row how-does-it-work">
      <h3>How does it work </h3>
      <b-row>
        <img
          class="logo"
          alt="Vue logo"
          src="../assets/images/howdoesitwork.svg"
        >
        <b-col>
          <h4>STEP 1: </h4>
          <span>Farmer produces energy metering company measures produced energy every 15 minutes </span>
        </b-col>
        <b-col>
          <h4>STEP 2: </h4>
          <span>Farmer and consumer can see their usage and production in the dashboard </span>
        </b-col>
        <b-col>
          <h4> STEP 3:</h4>
          <span>Farmer and consumer can see their usage and production in the dashboard</span>
        </b-col>
      </b-row>
    </b-container>
    <b-container class="four-table">
      <H3>Functions tool</H3>
      <b-row>

        <b-col> <img
            class="logo"
            alt="Vue logo"
            src="../assets/images/group-4.svg"
          >
          <h5>Create</h5>
          <span>Place where users can be created</span>
          <h5>Create Consumer & Create Producer</h5>
        </b-col>
        <b-col>
          <img
            class="logo"
            alt="Vue logo"
            src="../assets/images/mill-electricity.svg"
          >
          <h5>Run Energy Bank Job</h5>
          <span>The by farmer produced energy will be measured
            by metering company and stored in storage bank</span>
          <h5>Store Energybank</h5>
        </b-col>
      </b-row>
    </b-container>

    <b-container class="four-table block-images">

      <b-row>
        <b-col> <img
            class="logo"
            alt="Vue logo"
            src="../assets/images/allocateenergy.svg"
          >
          <h5>Run Energy Allocation Job</h5>
          <span>User can access the farmer's storage bank
            transfer power to consumers</span>
          <h5>Allocate Energy</h5>
        </b-col>
        <b-col>
          <img
            class="logo"
            alt="Vue logo"
            src="../assets/images/monitoring-energy.svg"
          >
          <h5>Monitoring</h5>
          <span>Farmer and consumer can see their usage and
            production in the dashboard</span>
          <h5>Data Producer
            Data Consumer</h5>
        </b-col>
      </b-row>
    </b-container>
    <b-container class="bv-example-row questions">
      <h3>
        Frequently Asked Questions
      </h3>
      <b-row>
        <b-col>
          <h5>
            Why Ethereum
          </h5>
          <span>
            Ethereum is chosen as a Blockchain for this solution because it is one of the most widely used. Furthermore it's the most mature Blockchain that supports Smart Contracts.
          </span>
        </b-col>
      </b-row>
      <b-row>
        <b-col>
          <h5>
            What is MetaMask?
          </h5>
          <span>
            3rd Party wallet MetaMask is a browser plugin that makes it possible to make transactions on behalf of a Blockchain account. This can be an automatic system or hardware wallet.
          </span>
        </b-col>
      </b-row>
    </b-container>
    <div class="bottom-bar">
    </div>
  </div>
</template>      
<script lang="ts">
import Vue from 'vue';

export default Vue.extend({
  name: 'AboutGreenEnergy',
});
</script>



<style scoped lang="scss">
@import "../../src/assets/scss/components/about.scss";
</style>