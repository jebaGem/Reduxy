<template>
  <div class="run-energy">
    <h2 class="page-header">{{$options.name}}</h2>
    <div class="run-energy-header">
      <h3>Allocate Energy from producer to consumer</h3>
      <p>Choose the producer you want to allocate the energy from</p>
    </div>
    <div class="run-energy-block allocation">
      <b-container class="run-energy-container">
        <b-form @submit="onSubmit" @reset="onReset">
          <b-form-group>
            <b-row class="run-energy-row">
              <b-col>
                <Steps
                  stepsNumber="1"
                  stepText=" "
                  stepTitle="Producer "
                  stepDescription="Choose the producer you want to allocate the energy form"
                ></Steps>
              </b-col>
              <b-col>
                <b-form-select
                  v-model="selectedProductionLocationId"
                  name="producers"
                  @change="onChange($event);loadEnergyBank();resetSelection('producer')"
                  class="form-control"
                >
                  <option key="-1" value="-1">Select a producer</option>
                  <option
                    v-bind:key="item.Id"
                    v-bind:value="item.Id"
                    v-for="item of productionLocations"
                  >{{item.Id}}: {{item.Name}}</option>
                </b-form-select>
              </b-col>
            </b-row>
          </b-form-group>
          <b-form-group>
            <b-row class="run-energy-row" v-bind:class="{  fadeItems : !dafaultSelectionProducer}">
              <b-col>
                <Steps
                  stepsNumber="2"
                  stepText=" "
                  stepTitle="Energy Bank "
                  stepDescription="Choose the energyslot"
                ></Steps>
              </b-col>
              <b-col>
                <b-list-group>
                  <b-list-group-item
                    v-for="item of energyBankEntries"
                    v-bind:key="item.Period"
                    v-bind:class="{ active: item.Period == selectedBankEntryPeriod }"
                    v-on:click="selectedBankEntryPeriod = item.Period;resetSelection('energy')"
                    href="#"
                  >{{item.Period}}: {{item.Energy}}</b-list-group-item>
                </b-list-group>
              </b-col>
            </b-row>
          </b-form-group>
          <b-form-group>
            <b-row class="run-energy-row" v-bind:class="{  fadeItems : selectedBankEntryPeriod<0}">
              <b-col>
                <Steps
                  stepsNumber="3"
                  stepText=" "
                  stepTitle="Consumer "
                  stepDescription="Choose the consumer you want to allocate the energy to"
                ></Steps>
              </b-col>
              <b-col>
                <b-form-select
                  name="consumers"
                  @change="onChangeConsumer($event);resetSelection('consumer')"
                  class="form-control"
                  v-model="selectedConsumptionLocationId"
                >
                  <option key="-1" value="-1">Select a consumer</option>
                  <option
                    v-bind:key="item.Id"
                    v-bind:value="item.Id"
                    v-for="item of consumptionLocations"
                  >{{item.Id}}: {{item.Name}}</option>
                </b-form-select>
              </b-col>
            </b-row>
          </b-form-group>
          <b-form-group id="selectedPeriodInputGroup">
            <b-row class="run-energy-row" v-bind:class="{  fadeItems : !dafaultSelectionConsumer}">
              <b-col>
                <Steps
                  class="step-4"
                  stepsNumber="4"
                  stepText=" "
                  stepTitle="Period "
                  stepDescription="Choose the consumer you want to allocate the energy to"
                ></Steps>
              </b-col>
              <b-col>
                <b-form-select
                  id="periodInput"
                  :options="periods"
                  required
                  v-model="form.selectedPeriod"
                ></b-form-select>
              </b-col>
            </b-row>
          </b-form-group>
          <b-form-group
            id="energyToAllocateInputGroup"
            v-bind:class="{  fadeItems : form.selectedPeriod < 0}"
          >
            <b-row class="run-energy-row" v-bind:class="{  fadeItems : !dafaultSelectionConsumer}">
              <b-col>
                <Steps
                  class="step-5"
                  stepsNumber="5"
                  stepText=" "
                  stepTitle="Amount "
                  stepDescription="Choose the amount of energy to allocate"
                ></Steps>
              </b-col>
              <b-col>
                <b-form-input
                  id="energyInput"
                  type="number"
                  v-model="form.energyToAllocate"
                  required
                  placeholder="The amount of energy to allocate to the specified consumer for this period"
                ></b-form-input>
              </b-col>
            </b-row>
          </b-form-group>
          <b-button type="submit" variant="primary">Submit</b-button>
        </b-form>
      </b-container>
    </div>
  </div>
</template>

<script lang='ts'>
import Vue from 'vue';

import Web3 from 'web3';
import Web3ObjectProvider from '@/ethereumStuff/Web3ObjectProvider';
import ContractProvider from '@/ethereumStuff/ContractProvider';

import store from '@/config/Store';
import jobsStore from '@/code/JobsStore';
import { SetJobStateArguments, JobState } from '@/code/JobsStore';

import { ILocation, IEnergyBankEntry } from '@/ethereumStuff/Interfaces';
import Steps from '@/components/Steps.vue';

export default Vue.extend({
  name: 'RunEnergyAllocation',
  components: {
    Steps,
  },
  async mounted() {
    console.log('Mounted');
    this.debugMsg(`Mounted ${this.$options.name}`);
    await this.loadLocations();
    await this.loadEnergyBank();
  },
  methods: {
    debugMsg(msg: string) {
      this.$root.$emit('debugMsg', msg);
    },
    onChange(event: string | number) {
      this.selectedProductionLocationId = +event;
    },
    onChangeConsumer(event: string | number) {
      this.selectedConsumptionLocationId = +event;
    },
    async loadLocations() {
      const ctr = await ContractProvider.getGreenEnergyContract();

      this.productionLocations = [];
      const amountOfProdLocs = (await ctr.methods.getProductionLocationsCount().call()) as number;
      for (let i = 0; i < amountOfProdLocs; i++) {
        const locationName = await ctr.methods.getProductionLocationName(i).call();
        this.productionLocations.push({ Id: i, Name: locationName });
      }
      const amountOfConsLocs = (await ctr.methods.getConsumptionLocationsCount().call()) as number;
      for (let i = 0; i < amountOfConsLocs; i++) {
        const locationName = await ctr.methods.getConsumptionLocationName(i).call();
        this.consumptionLocations.push({ Id: i, Name: locationName });
      }
    },
    async resetSelection(typeOfReset: string) {
      this.dafaultSelectionProducer = true;
      switch (typeOfReset) {
        case 'producer':
          this.dafaultSelectionProducer = true;
          this.dafaultSelectionConsumer = false;
          this.selectedBankEntryPeriod = -1;
          this.selectedConsumptionLocationId = -1;
          this.resetFlags();
          break;
        case 'energy':
          this.form.selectedPeriod = -1;
          this.form.energyToAllocate = 0;
          this.selectedConsumptionLocationId = -1;
          this.dafaultSelectionConsumer = false;
          break;
        case 'consumer':
          this.dafaultSelectionConsumer = true;
          this.form.selectedPeriod = -1;
          this.form.energyToAllocate = 0;
          break;
        default:
          break;
      }
    },
    async resetFlags() {
      this.selectedBankEntryPeriod = -1;
      this.form.selectedPeriod = -1;
      this.form.energyToAllocate = 0;
    },
    async loadEnergyBank() {
      if (this.selectedProductionLocationId !== -1) {
        const ctr = await ContractProvider.getGreenEnergyContract();

        this.energyBankEntries = [];
        const wholeBank = await ctr.methods.getWholeEnergyBank(this.selectedProductionLocationId).call();

        for (let i = 0; i < wholeBank.productionDates.length; i++) {
          // Remove the default selection of bank entry period
          // if (i === 0) {
          //  this.selectedBankEntryPeriod = wholeBank.productionDates[i];
          // }
          this.energyBankEntries.push({
            Period: wholeBank.productionDates[i],
            Energy: wholeBank.quantities[i],
          });
        }
      }
    },
    async onSubmit(evt: Event) {
      evt.preventDefault();
      const theJob = await jobsStore.dispatch('addJob', `Allocating ${this.form.energyToAllocate} energy from ${this.productionLocations[this.selectedProductionLocationId].Name} to ${this.consumptionLocations[this.selectedConsumptionLocationId].Name} from period ${this.selectedBankEntryPeriod} to period ${this.form.selectedPeriod}...`);

      const ctr = await ContractProvider.getGreenEnergyContract();

      await jobsStore.dispatch('setJobState', {
        Job: theJob,
        NewState: JobState.Running,
      });

      try {
        const transResult = await ctr.methods.transferEnergy(this.selectedProductionLocationId, this.selectedConsumptionLocationId, [this.selectedBankEntryPeriod], [this.form.energyToAllocate], [this.form.selectedPeriod]).send();

        await jobsStore.dispatch('setJobState', {
          Job: theJob,
          NewState: JobState.Completed,
        });
      } catch (ex) {
        const error = ex.toString();
        this.debugMsg(error);
        const isCancelled = error.endsWith('User denied transaction signature.');
        if (!isCancelled) {
          this.$root.$emit('openDebugBox');
        }
        await jobsStore.dispatch('setJobState', {
          Job: theJob,
          NewState: isCancelled ? JobState.Cancelled : JobState.Failed,
          Reason: isCancelled ? 'Cancelled by used' : 'An error occured during this transaction, see the debug box.',
        });
      }

      await this.loadEnergyBank();
    },
    onReset(evt: Event) {
      evt.preventDefault();
      /* Reset our form values */
      this.form.selectedPeriod = 0;
      this.form.energyToAllocate = 0;

      /* Trick to reset/clear native browser form validation state */
      this.show = false;
      this.$nextTick(() => {
        this.show = true;
      });
    },
  },
  data() {
    return {
      dafaultSelectionProducer: false,
      dafaultSelectionConsumer: false,
      web3: Web3ObjectProvider.getWeb3(),
      show: true,
      productionLocations: [] as ILocation[],
      consumptionLocations: [] as ILocation[],
      selectedProductionLocationId: -1,
      selectedConsumptionLocationId: -1,
      selectedBankEntryPeriod: -1,
      periods: [
        { value: -1, text: 'Select a period' },
        { value: 0, text: '0: 00:00 - 00:15' },
        { value: 1, text: '1: 00:15 - 00:30' },
        { value: 2, text: '2: 00:30 - 00:45' },
        { value: 3, text: '3: 00:45 - 01:00' },
        { value: 4, text: '4: 01:00 - 01:15' },
        { value: 5, text: '5: 01:15 - 01:30' },
        { value: 6, text: '6: 01:30 - 01:45' },
        { value: 7, text: '7: 01:45 - 02:00' },
        { value: 8, text: '8: 02:00 - 02:15' },
        { value: 9, text: '9: 02:15 - 02:30' },
      ],
      form: {
        selectedPeriod: -1,
        energyToAllocate: 0,
      },
      energyBankEntries: [] as IEnergyBankEntry[],
    };
  },
});
</script>
<style scoped>
#debugBox {
  margin-top: 10px;
}
</style>

<style scoped lang="scss">
@import '../../src/assets/scss/components/runEnergy.scss';
</style>


