<template>
  <div class="run-energy">
    <h2 class="page-header">{{$options.name}}</h2>
     <div class="row my-1">
      <div id="steps1" class="col-sm-4 steps step-header-page">
      <Steps 
      stepsNumber="1"
        stepText="Step 1 :" 
        stepTitle="Choose your producer "
        stepDescription="Choose the producer you want to allocate the energy form"
        >
      </Steps>
    </div>
    <div id="steps2" class="col-sm-4 steps step-header-page second">
      <Steps 
      stepsNumber="2"
        stepText="Step 2 :" 
        stepTitle="Run Energy Bank "
        stepDescription="Choose the period and the amount of energy you want to store"
        >
      </Steps>
    </div>
     </div>
    <b-container fluid class="run-energy-container">
      <b-row class="my-1">
        <b-col sm="4">
        <div class="left-side-space-border-div">
          <h3>Existing Producers:</h3>
          <b-list-group>
            <b-list-group-item v-for="item of productionLocations" v-bind:key="item.Id" v-bind:class="{ active: item.Id == selectedProductionLocationId && dafaultSelectionProducer}" v-on:click="selectedProductionLocationId = item.Id; loadEnergyBank(); resetSelection('producer')" href="#">
              {{item.Id}}: {{item.Name}}
            </b-list-group-item>
          </b-list-group>
          </div>
        </b-col>
        <b-col sm="4"  v-bind:class="{  fadeItems : !dafaultSelectionProducer}">
        <div class="left-side-space-border-div middle">
          <b-form @submit="onSubmit" @reset="onReset" v-if="show">
            <b-form-group id="selectedPeriodInputGroup"
                          label="Period:"
                          label-for="periodInput"
                          description="Choose the period"
                          vertical>
                <b-form-select id="periodInput"
                            :options="periods"
                            required
                            v-model="form.selectedPeriod">
                </b-form-select>
            </b-form-group>
            <b-form-group id="energyToAddInputGroup"
                          label="Energy to store:"
                          label-for="energyInput"
                          description="Choose the amount of energy to store"
                          vertical>
                <b-form-input id="energyInput"
                            type="number"
                            v-model="form.energyToStore"
                            required
                            placeholder="The amount of energy to add to the energy bank for this period">
                </b-form-input>
            </b-form-group>
            <b-button type="submit" variant="primary">Submit</b-button>
            
          </b-form>
          </div>
        </b-col>
        <b-col sm="4" class="energy-bank"   v-bind:class="{  fadeItems : !dafaultSelectionProducer}">
         <div class="left-side-space-border-div right">
          <h3>Energy Bank:</h3>
          <div v-if="!dafaultSelectionProducer">
          <h4 style="text-align:left"> Please select the producer to view the energy banks </h4>
          </div> 
          <div v-if="productionLocations.length > 0 && selectedProductionLocationId >= 0 && dafaultSelectionProducer">
          <h3>{{this.productionLocations[this.selectedProductionLocationId].Name}}</h3>
          
          <b-list-group>
            <b-list-group-item v-for="item of energyBankEntries" v-bind:key="item.Period">
              {{item.Period}}: {{item.Energy}}
            </b-list-group-item>
          </b-list-group>
          </div>
          </div>
        </b-col>
      </b-row>      
    </b-container>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';

import Web3 from 'web3';
import Web3ObjectProvider from '@/ethereumStuff/Web3ObjectProvider';
import ContractProvider from '@/ethereumStuff/ContractProvider';

import store from '@/config/Store';
import jobsStore from '@/code/JobsStore';
import { SetJobStateArguments, JobState } from '@/code/JobsStore';

import { ILocation, IEnergyBankEntry } from '@/ethereumStuff/Interfaces';
import Steps from '@/components/Steps.vue';

export default Vue.extend({
  name: 'RunEnergyBank',
   components: {
    Steps,
  },
  async mounted() {
    console.log('Mounted');
    this.debugMsg(`Mounted ${this.$options.name}`);
    await this.loadProductionLocations();
    await this.loadEnergyBank();
  },
  methods: {
    debugMsg(msg: string) {
      this.$root.$emit('debugMsg', msg);
    },
    async loadProductionLocations() {
      const ctr = await ContractProvider.getGreenEnergyContract();

      this.productionLocations = [];
      const amountOfLocs = await ctr.methods.getProductionLocationsCount().call() as number;
      for (let i = 0; i < amountOfLocs; i++) {
        const locationName = await ctr.methods.getProductionLocationName(i).call();
        this.productionLocations.push({ Id: i, Name: locationName });
      }
    },
    async loadEnergyBank() {
      const ctr = await ContractProvider.getGreenEnergyContract();

      this.energyBankEntries = [];
      const wholeBank = await ctr.methods.getWholeEnergyBank(this.selectedProductionLocationId).call();

      for (let i = 0; i < wholeBank.productionDates.length; i++) {
        this.energyBankEntries.push({ Period: wholeBank.productionDates[i], Energy: wholeBank.quantities[i] });
      }
    },
     async resetSelection(typeOfReset: string) {
        switch (typeOfReset) {
        case 'producer':
        this.form.selectedPeriod = -1;
        this.form.energyToStore = 0;
        this.dafaultSelectionProducer = true;
        break;
        default:
        break;
      }
    },
    async onSubmit(evt: Event) {
      evt.preventDefault();
      const theJob = await jobsStore.dispatch('addJob', `Adding ${this.form.energyToStore} energy to ${this.productionLocations[this.selectedProductionLocationId].Name} for period: ${this.form.selectedPeriod}...`);

      const ctr = await ContractProvider.getGreenEnergyContract();

      await jobsStore.dispatch('setJobState', { Job: theJob, NewState: JobState.Running});

      try {
        const transResult = await ctr.methods.depositEnergy(
          this.selectedProductionLocationId,
          [ this.form.energyToStore ],
          [ this.form.selectedPeriod ],
        ).send();

        await jobsStore.dispatch('setJobState', { Job: theJob, NewState: JobState.Completed});
      } catch (ex) {
        const error = ex.toString();
        this.debugMsg(error);
        const isCancelled = error.endsWith('User denied transaction signature.');
        if (!isCancelled) {
          this.$root.$emit('openDebugBox');
        }
        await jobsStore.dispatch('setJobState', { Job: theJob, NewState: isCancelled ? JobState.Cancelled : JobState.Failed, Reason: isCancelled ? 'Cancelled by used' : 'An error occured during this transaction, see the debug box.'});
      }

      await this.loadEnergyBank();
    },
    onReset(evt: Event) {
      evt.preventDefault();
      /* Reset our form values */
      this.form.selectedPeriod = 0;
      this.form.energyToStore = 0;

      /* Trick to reset/clear native browser form validation state */
      this.show = false;
      this.$nextTick(() => { this.show = true; });
    },
  },
  data() {
    return {
      web3: Web3ObjectProvider.getWeb3(),
      dafaultSelectionProducer: false,
      show: true,
      productionLocations: [] as ILocation[],
      selectedProductionLocationId: 0,
      periods: [
        { value: 0, text: '0: 00:00 - 00:15' },
        { value: 1, text: '1: 00:15 - 00:30' },
        { value: 2, text: '2: 00:30 - 00:45' },
        { value: 3, text: '3: 00:45 - 01:00' },
        { value: 4, text: '4: 01:00 - 01:15' },
        { value: 5, text: '5: 01:15 - 01:30' },
        { value: 6, text: '6: 01:30 - 01:45' },
        { value: 7, text: '7: 01:45 - 02:00' },
        { value: 8, text: '8: 02:00 - 02:15' },
        { value: 9, text: '9: 02:15 - 02:30' },
      ],
      form: {
        selectedPeriod: -1,
        energyToStore: 0,
      },
      energyBankEntries: [] as IEnergyBankEntry[],
    };
  },
});
</script>

<style scoped lang="scss">
@import "../../src/assets/scss/components/runEnergy.scss";
</style>