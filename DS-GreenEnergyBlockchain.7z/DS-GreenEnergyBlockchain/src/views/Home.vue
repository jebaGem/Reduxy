 <template>
   <div id="app">
    <div class="top-green"></div>
      <Jobs/>
    <div id="headerBar" class="header">
      <HeaderBar/>
    </div>
    <router-view/>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';

import Web3 from 'web3';
import Web3ObjectProvider from '@/ethereumStuff/Web3ObjectProvider';
import ContractProvider from '@/ethereumStuff/ContractProvider';

import store from '@/config/Store';
import Jobs from '@/components/Jobs.vue';

import jobsStore from '@/code/JobsStore';
import { SetJobStateArguments, JobState } from '@/code/JobsStore';

import HeaderBar from '@/components/HeaderBar.vue';
import DebugBox from '@/components/DebugBox.vue';

export default Vue.extend({
  name: 'Home',
  components: {
    HeaderBar,
    DebugBox,
    Jobs,
  },
  async mounted() {
    console.log('Mounted');

    this.debugMsg(`Mounted ${this.$options.name}`);
  },
  methods: {
    async uploadContract() {
      this.debugMsg('Uploading contract...');
      this.isWorking = true;
      this.progressCounter = 0;
      this.status = 'primary';

      const theJob = await jobsStore.dispatch('addJob', 'Uploading contract...');

      try {
        const accs = await this.web3.eth.getAccounts();

        const ctr = await ContractProvider.getGreenEnergyContract();

        this.progressCounter = 10;

        const transObject = ctr.deploy(
          {
            data: ctr.options.data,
            arguments: [accs[0], accs[0]],
          },
        );

        this.progressCounter = 20;

        // const estGas = await transObject.estimateGas();
        await jobsStore.dispatch('setJobState', { Job: theJob, NewState: JobState.Running});
        const sendTrans = await transObject.send();

        this.progressCounter = 90;

        const adr = (sendTrans as any)._address;

        store.commit('setContractAddress', adr);
        ContractProvider.removeStoredContractInstance();

        this.debugMsg(`ContractAddress: ${adr}`);
        this.progressCounter = 100;
        this.status = 'success';
        await jobsStore.dispatch('setJobState', { Job: theJob, NewState: JobState.Completed});
      } catch (ex) {
        const error = ex.toString();
        this.debugMsg(error);
        this.status = 'danger';
        const isCancelled = error.endsWith('User denied transaction signature.');
        if (!isCancelled) {
          this.$root.$emit('openDebugBox');
        }
        await jobsStore.dispatch('setJobState', { Job: theJob, NewState: isCancelled ? JobState.Cancelled : JobState.Failed, Reason: isCancelled ? 'Cancelled by used' : 'An error occured during this transaction, see the debug box.'});
      }
      this.isWorking = false;
    },
    debugMsg(msg: string) {
      this.$root.$emit('debugMsg', msg);
    },
  },
  computed: {
    storeState() {
      return store.state;
    },
  },
  data() {
    return {
      web3: Web3ObjectProvider.getWeb3(),
      isWorking: false,
      progressCounter: 0,
      status: 'primary',
    };
  },
});
</script>

<style scoped>
#debugBox {
  margin-top: 10px;
}
</style>
