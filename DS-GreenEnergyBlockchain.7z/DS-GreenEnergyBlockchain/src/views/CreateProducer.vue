<template>
  <div>
    <h2 class="page-header">{{$options.name}}</h2>
    <b-container fluid>
      <div class="marginTopClass">
        <b-row>
          <b-col sm="6">
            <div class="left-side-space-border-div">
              <b-form class="green-energy-form" @submit="onSubmit" @reset="onReset" v-if="show">
                <b-form-group class="producer-section" id="producerNameInputGroup" vertical>
                  <p class="producerNameLabel">Producer Name:</p>
                  <div class="padContentProducerName">
                    <b-form-input
                      id="producerNameInput"
                      type="text"
                      v-model="form.producerName"
                      required
                      placeholder="Enter Producer Name"
                    ></b-form-input>
                    <b-button type="submit" variant="primary">Submit</b-button>
                  </div>
                </b-form-group>
              </b-form>
            </div>
          </b-col>
          <b-col sm="6" class="padContent">
            <div class="existing-producer">
              <h3>Existing Producers:</h3>
              <b-list-group>
                <b-list-group-item
                  v-for="item of productionLocations"
                  v-bind:key="item.Id"
                >{{item.Id}}: {{item.Name}}</b-list-group-item>
              </b-list-group>
            </div>
          </b-col>
        </b-row>
      </div>
    </b-container>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';

import Web3 from 'web3';
import Web3ObjectProvider from '@/ethereumStuff/Web3ObjectProvider';
import ContractProvider from '@/ethereumStuff/ContractProvider';

import store from '@/config/Store';
import jobsStore from '@/code/JobsStore';
import { SetJobStateArguments, JobState } from '@/code/JobsStore';

import { ILocation } from '@/ethereumStuff/Interfaces';

export default Vue.extend({
  name: 'CreateProducer',
  async mounted() {
    console.log('Mounted');
    this.debugMsg(`Mounted ${this.$options.name}`);
    await this.loadProductionLocations();
  },
  methods: {
    debugMsg(msg: string) {
      this.$root.$emit('debugMsg', msg);
    },
    async loadProductionLocations() {
      const ctr = await ContractProvider.getGreenEnergyContract();

      this.productionLocations = [];
      const amountOfLocs = (await ctr.methods.getProductionLocationsCount().call()) as number;
      for (let i = 0; i < amountOfLocs; i++) {
        const locationName = await ctr.methods.getProductionLocationName(i).call();
        this.productionLocations.push({ Id: i, Name: locationName });
      }
    },
    async onSubmit(evt: Event) {
      evt.preventDefault();
      const theJob = await jobsStore.dispatch('addJob', `Creating consumer '${this.form.producerName}'...`);

      const ctr = await ContractProvider.getGreenEnergyContract();

      await jobsStore.dispatch('setJobState', { Job: theJob, NewState: JobState.Running });

      try {
        const transResult = await ctr.methods.createProductionLocation(this.form.producerName).send();

        await jobsStore.dispatch('setJobState', { Job: theJob, NewState: JobState.Completed });
      } catch (ex) {
        const error = ex.toString();
        this.debugMsg(error);
        const isCancelled = error.endsWith('User denied transaction signature.');
        if (!isCancelled) {
          this.$root.$emit('openDebugBox');
        }
        await jobsStore.dispatch('setJobState', { Job: theJob, NewState: isCancelled ? JobState.Cancelled : JobState.Failed, Reason: isCancelled ? 'Cancelled by used' : 'An error occured during this transaction, see the debug box.' });
      }
      await this.loadProductionLocations();
    },
    onReset(evt: Event) {
      evt.preventDefault();
      /* Reset our form values */
      this.form.producerName = '';

      /* Trick to reset/clear native browser form validation state */
      this.show = false;
      this.$nextTick(() => {
        this.show = true;
      });
    },
  },
  data() {
    return {
      web3: Web3ObjectProvider.getWeb3(),
      show: true,
      form: {
        producerName: '',
      },
      productionLocations: [] as ILocation[],
    };
  },
});
</script>

<style scoped lang="scss">
@import '../../src/assets/scss/components/createProducerConsumer.scss';
</style>

