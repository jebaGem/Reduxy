<template>
  <div class="greenenergy-page">
    <h2 class="page-header">{{$options.name}}</h2>
    <b-container fluid class="consumer-container">
      <div class="marginTopClass">
        <b-row class="my-1">
          <b-col sm="5" class="left-side-space-border-div">
            <h3>Existing Consumers:</h3>
            <b-list-group>
              <b-list-group-item
                v-for="item of consumptionLocations"
                v-bind:key="item.Id"
                v-bind:class="{ active: item.Id == selectedConsumptionLocationId }"
                v-on:click="selectedConsumptionLocationId = item.Id; loadAllocationData()"
                href="#"
              >{{item.Id}}: {{item.Name}}</b-list-group-item>
            </b-list-group>
          </b-col>
          <b-col sm="6" class="green-energy-table">
            <b-table striped hover :items="energyPerPeriod" :fields="energyPerPeriodFields"></b-table>
          </b-col>
        </b-row>
        <b-row>
          <b-col sm="12">
            <h3 class="chart-title">Usage Energy Bank</h3>
            <GChart
              class="green-energy-chart"
              type="ColumnChart"
              :data="chartData"
              :options="chartOptions"
              style="width: 93% !important; height: 600px;margin: 0 0 50px 4%;"
            />
          </b-col>
        </b-row>
      </div>
    </b-container>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';

import Web3 from 'web3';
import Web3ObjectProvider from '@/ethereumStuff/Web3ObjectProvider';
import { EventLog } from 'web3/types';
import ContractProvider from '@/ethereumStuff/ContractProvider';

import store from '@/config/Store';

import { ILocation, IEnergyBankEntry, IEnergyPerPeriod } from '@/ethereumStuff/Interfaces';

export default Vue.extend({
  name: 'Consumers',
  async mounted() {
    console.log('Mounted');
    this.debugMsg(`Mounted ${this.$options.name}`);
    await this.loadLocations();
    await this.loadAllocationData();
  },
  methods: {
    debugMsg(msg: string) {
      this.$root.$emit('debugMsg', msg);
    },
    async loadLocations() {
      const ctr = await ContractProvider.getGreenEnergyContract();

      this.consumptionLocations = [];
      const amountOfConsLocs = (await ctr.methods.getConsumptionLocationsCount().call()) as number;
      for (let i = 0; i < amountOfConsLocs; i++) {
        const locationName = await ctr.methods.getConsumptionLocationName(i).call();
        this.consumptionLocations.push({ Id: i, Name: locationName });
      }
    },
    async loadAllocationData() {
      const ctr = await ContractProvider.getGreenEnergyContract();

      const start = 0;
      const end = 10;

      const theEnergyPeriods: IEnergyPerPeriod[] = [];
      const chartData: any[][] = [];

      for (let i = start; i < end; i++) {
        const energyPerPeriodItem: IEnergyPerPeriod = {
          Period: i,
          Bank: 0,
          LightGreen: 0,
          DarkGreen: 0,
        };
        theEnergyPeriods.push(energyPerPeriodItem);
      }

      const allEvents = await ctr.getPastEvents('EnergyTransfered', {
        filter: { consumerLocationId: [this.selectedConsumptionLocationId] },
        fromBlock: 0,
      });

      for (const curEventLog of allEvents) {
        const curPeriod = parseInt(curEventLog.returnValues.transferDate, 10);
        const parsedQuanity = parseInt(curEventLog.returnValues.quantity, 10);

        if (curEventLog.returnValues.transferType === '0') {
          // Dark Green Energy
          theEnergyPeriods[curPeriod].DarkGreen += parsedQuanity;
        } else if (curEventLog.returnValues.transferType === '1') {
          // Light Green Energy
          theEnergyPeriods[curPeriod].LightGreen += parsedQuanity;
        }
      }

      chartData.push(['Period', 'DarkGreen', 'LightGreen']);
      for (const curPeriod of theEnergyPeriods) {
        chartData.push([`${curPeriod.Period}`, curPeriod.DarkGreen, curPeriod.LightGreen]);
      }

      this.energyPerPeriod = theEnergyPeriods;
      this.chartData = chartData;
    },
  },
  data() {
    return {
      web3: Web3ObjectProvider.getWeb3(),
      consumptionLocations: [] as ILocation[],
      selectedConsumptionLocationId: 0,
      energyPerPeriod: [] as IEnergyPerPeriod[],
      energyPerPeriodFields: [{ key: 'Period', sortable: true }, { key: 'DarkGreen', sortable: true }, { key: 'LightGreen', sortable: true }],
      chartData: [['Period', 'DarkGreen', 'LightGreen'], ['0', 0, 0]],
      chartOptions: {
        chart: {
          title: 'Energy Consumption',
        },
        series: {
          0: { color: '#0b8d5c' },
          1: { color: '#12c481' },
          2: { color: '#f9a638' },
        },
        isStacked: true,
        animation: {
          duration: 500,
          easing: 'out',
        },
      },
    };
  },
});
</script>

<style scoped lang="scss">
@import '../../src/assets/scss/components/consumerProducer.scss';
</style>