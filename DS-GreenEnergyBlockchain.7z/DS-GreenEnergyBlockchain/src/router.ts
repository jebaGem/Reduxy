import Vue from 'vue';
import Router from 'vue-router';
import BootstrapVue from 'bootstrap-vue';
import VueGoogleCharts from 'vue-google-charts';
import 'vue-awesome/icons';
import Icon from 'vue-awesome/components/Icon.vue';

import Home from './views/Home.vue';
import CreateProducer from './views/CreateProducer.vue';
import CreateConsumer from './views/CreateConsumer.vue';
import RunEnergyAllocation from './views/RunEnergyAllocation.vue';
import RunEnergyBank from './views/RunEnergyBank.vue';
import Producers from './views/Producers.vue';
import Consumers from './views/Consumers.vue';
import AboutGreenEnergy from './views/AboutGreenEnergy.vue';

import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap-vue/dist/bootstrap-vue.css';

Vue.use(Router);
Vue.use(BootstrapVue);
Vue.use(VueGoogleCharts);
Vue.component('v-icon', Icon);

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      name: 'home',
      component: AboutGreenEnergy,
    },
    {
      path: '/home',
      // You could also have named views at tho top
      component: Home,
      children: [{
        path: 'createproducer',
        component: CreateProducer,
      }, {
        path: 'createconsumer',
        component: CreateConsumer,
      },
      {
        path: 'runenergybank',
        component: RunEnergyBank,
      },
      {
        path: 'runenergyallocation',
        component: RunEnergyAllocation,
      },
      {
        path: 'producers',
        component: Producers,
      },
      {
        path: 'consumers',
        component: Consumers,
      },
      ],
    },


    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import(/* webpackChunkName: "about" */ './views/About.vue'),
    },
  ],
});
