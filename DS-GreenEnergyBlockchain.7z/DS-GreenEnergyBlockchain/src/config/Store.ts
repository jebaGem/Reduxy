import Vue from 'vue';
import Vuex, { StoreOptions } from 'vuex';

Vue.use(Vuex);

export interface RootState {
    contractAddress: string;
}

const store: StoreOptions<RootState> = {
    state: {
        contractAddress: '0xd3b4D42077A6a45046C7B70d36cB55CFAB48d0F4',
    },
    mutations: {
        setContractAddress(state, contractAddress: string) {
          state.contractAddress = contractAddress;
        },
    },
};

export default new Vuex.Store<RootState>(store);
