import Vue from 'vue';
import Vuex, { StoreOptions } from 'vuex';
import { cpus } from 'os';

Vue.use(Vuex);

export enum JobState {
    New,
    Running,
    Completed,
    Failed,
    Cancelled,
}

export interface IJob {
    Id: number;
    Name: string;
    State: JobState;
    Reason: string;
}

export interface JobsStoreState {
    jobs: IJob[];
    curJobId: number;
    jobWindowState: boolean;
    jobWindowStateCounter: number;
}

export interface SetJobStateArguments {
    Job: IJob;
    NewState: JobState;
    Reason: string;
}

const store: StoreOptions<JobsStoreState> = {
    state: {
        jobs: [],
        curJobId: 0,
        jobWindowState: false,
        jobWindowStateCounter: 0,
    },
    actions: {
        addJob({ dispatch, commit, state }, name: string) {
            const newJob: IJob = {
                Id: state.curJobId,
                Name: name,
                State: JobState.New,
                Reason: '',
            };
            state.jobs.push(newJob);
            state.curJobId++;

            dispatch('openJobsWindowTemporary');

            return newJob;
        },
        setJobState({ dispatch, commit, state }, setJobStateArguments: SetJobStateArguments) {
            const index: number = state.jobs.indexOf(setJobStateArguments.Job);
            const newState = setJobStateArguments.NewState;
            if (index !== -1) {
                state.jobs[index].State = newState;
                state.jobs[index].Reason = setJobStateArguments.Reason;
            }

            if (newState === JobState.Completed) {
                setTimeout(() => {
                    commit('removeJob', setJobStateArguments.Job);
                }, 5000);
            }

            if (newState === JobState.Cancelled || newState === JobState.Failed) {
                setTimeout(() => {
                    commit('removeJob', setJobStateArguments.Job);
                }, 10000);
            }

            dispatch('openJobsWindowTemporary');
        },
        openJobsWindowTemporary({ commit, state }) {
            state.jobWindowStateCounter++;
            const cur = state.jobWindowStateCounter;
            state.jobWindowState = true;
            setTimeout(() => {
                commit('closeJobsWindow', cur);
            }, 5000);
        },
    },
    mutations: {
        removeJob(state, job: IJob) {
            const index: number = state.jobs.indexOf(job);
            if (index !== -1) {
                state.jobs.splice(index, 1);
            }
        },
        closeJobsWindow(state, jobWndowStateCounterValue: number) {
            if (state.jobWindowStateCounter === jobWndowStateCounterValue) {
                state.jobWindowState = false;
            }
        },
    },
};

export default new Vuex.Store<JobsStoreState>(store);
