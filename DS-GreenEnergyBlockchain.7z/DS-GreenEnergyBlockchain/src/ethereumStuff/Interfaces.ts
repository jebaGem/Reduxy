export interface ILocation {
    Id: number;
    Name: string;
}

export interface IEnergyBankEntry {
    Period: number;
    Energy: number;
}

export interface IEnergyTransferedEvent {
    ProductionLocationId: number;
    ConsumerLocationId: number;
    ProductionDate: number;
    Quantity: number;
    TransferDate: number;
}

export interface IEnergyPerPeriod {
    Period: number;
    LightGreen: number;
    DarkGreen: number;
    Bank: number;
}
