import Web3 from 'web3';

export default class Web3ObjectProvider {
    public static getWeb3() {
        if (Web3ObjectProvider.instance === undefined) {
            console.log('Creating new Web3 object');
            Web3ObjectProvider.instance = new Web3((window as any).web3.currentProvider);
        }
        return Web3ObjectProvider.instance;
    }

    private static instance: Web3;
}
