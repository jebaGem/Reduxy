import Web3 from 'web3';
import Contract from 'web3/eth/contract';

import Web3ObjectProvider from '@/ethereumStuff/Web3ObjectProvider';
import greenEnergyContractJson from '@/assets/SmartContracts/bin/GreenEnergyContract.json';

import store from '@/config/Store';

export default class ContractProvider {
    public static async getGreenEnergyContract() {
        if (ContractProvider.instance === undefined) {
            console.log('Creating new Contract object');
            const web3 = Web3ObjectProvider.getWeb3();

            const accs = await web3.eth.getAccounts();

            const theGasPrice = Web3.utils.toWei('2.1', 'gwei');

            const ctr = new web3.eth.Contract(greenEnergyContractJson.abi, store.state.contractAddress, {
                data: greenEnergyContractJson.bytecode,
                gas: 7500000,
                gasPrice: theGasPrice,
                from: accs[0],
            });
            ContractProvider.instance = ctr;
        }
        return ContractProvider.instance;
    }

    public static removeStoredContractInstance() {
        ContractProvider.instance = undefined;
    }

    private static instance?: Contract;
}
