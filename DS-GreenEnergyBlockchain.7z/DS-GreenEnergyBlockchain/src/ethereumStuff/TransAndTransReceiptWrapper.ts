import { Transaction } from 'web3/eth/types';
import { TransactionReceipt } from 'web3/types';

export class TransAndTransReceiptWrapper implements Transaction, TransactionReceipt {
    public transaction: Transaction;
    public transactionReceipt: TransactionReceipt | null;

    constructor(transaction: Transaction, transactionReceipt: TransactionReceipt | null = null) {
        this.transaction = transaction;
        this.transactionReceipt = transactionReceipt;
    }

    public SetTransactionReceipt(transactionReceipt: TransactionReceipt) {
        this.transactionReceipt = transactionReceipt;
    }

    // Transaction (This is all needed for sorting)
    get hash() { return this.transaction.hash; }
    get nonce() { return this.transaction.nonce; }
    get from(): string { return this.transaction.from !== undefined ? this.transaction.from.toString() : ''; }
    get to(): string { return this.transaction.to !== undefined ? this.transaction.to.toString() : ''; }
    get value() { return this.transaction.value; }
    get gasPrice() { return this.transaction.gasPrice; }
    get gas() { return this.transaction.gas; }
    get input() { return this.transaction.input; }
    get v() { return this.transaction.v; }
    get r() { return this.transaction.r; }
    get s() { return this.transaction.s; }

    // TransactionReceipt (This is all needed for sorting)
    get blockHash() { return this.transactionReceipt != null ? this.transactionReceipt.blockHash : ''; }
    get blockNumber() { return this.transactionReceipt != null ? this.transactionReceipt.blockNumber : 0; }
    get transactionIndex() { return this.transactionReceipt != null ? this.transactionReceipt.transactionIndex : 0; }
    get transactionHash() { return this.transactionReceipt != null ? this.transactionReceipt.transactionHash : ''; }
    get contractAddress() { return this.transactionReceipt != null ? this.transactionReceipt.contractAddress : ''; }
    get cumulativeGasUsed() { return this.transactionReceipt != null ? this.transactionReceipt.cumulativeGasUsed : 0; }
    get gasUsed() { return this.transactionReceipt != null ? this.transactionReceipt.gasUsed : 0; }
    get logs() { return this.transactionReceipt != null ? this.transactionReceipt.logs : undefined; }
    get events() { return this.transactionReceipt != null ? this.transactionReceipt.events : undefined; }
    get status() { return this.transactionReceipt != null ? (this.transactionReceipt as any).status : false; }
}
