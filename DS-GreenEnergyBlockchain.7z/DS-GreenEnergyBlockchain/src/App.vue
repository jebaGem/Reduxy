<template>
  <div id="app">

     <router-view/>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';
import HeaderBar from '@/components/HeaderBar.vue';
import DebugBox from '@/components/DebugBox.vue';

export default Vue.extend({
  name: 'App',
});
</script>


<style lang='scss'>
@import '../src/assets/scss/base/base.scss';
</style>

