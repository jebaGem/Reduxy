<template>
  <div>
    <b-card no-body style="max-width: 305px;">
      <router-link to="/">
        <div class="logo-div">
          <img class="logo" alt="Vue logo" src="../assets/images/logo.svg">
        </div>
        <h4 class="header-sol">solarchain</h4>
      </router-link>

      <b-list-group flush>
        <b-list-group-item>
          <router-link class="nav-link" to="/">Home</router-link>
        </b-list-group-item>
        <b-list-group-item>
          <router-link class="nav-link" to="/home/createproducer">Create Producer</router-link>
        </b-list-group-item>
        <b-list-group-item>
          <router-link class="nav-link" to="/home/createconsumer">Create Consumer</router-link>
        </b-list-group-item>
        <b-list-group-item>
          <router-link class="nav-link" to="/home/runenergybank">Run Energy Bank Job</router-link>
        </b-list-group-item>

        <b-list-group-item>
          <router-link class="nav-link" to="/home/runenergyallocation">Run Energy Allocation Job</router-link>
        </b-list-group-item>
        <b-list-group-item>
          <router-link class="nav-link" to="/home/producers">Producers</router-link>
        </b-list-group-item>
        <b-list-group-item>
          <router-link class="nav-link" to="/home/consumers">Consumers</router-link>
        </b-list-group-item>
      </b-list-group>
    </b-card>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';
import store from '@/config/Store';


export default Vue.extend({
  name: 'HeaderBar',
  computed: {
    storeState() {
      return store.state;
    },
  },
});
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
@import "../../src/assets/scss/layout/header.scss";
</style>
