<template>
  <div class="jobs-container">
  <div class="job-container" v-on:click="showJobs(!show)">
 <div  class="jobs-count">       
    {{storeState.jobs.length}}</div>
    <img  src="../assets/images/task.png" class="task-image" alt="Avatar" style="width:32px;border-radius:50%;">
    <label class="task-list-label">Task List 
    <i class="arrow down" 
   ></i></label>
    </div>
    <img src="../assets/images/img_avatar.png" class="account-image" alt="Avatar" style="width:32px;border-radius:50%;">
    <label class="task-list-account">Account 
    <i class="arrow down"></i>
    </label>
  <div class="jobs" id="jobs" v-if="show || storeState.jobWindowState">
    <b-list-group>
    <label class="no-jobs-running" v-if="storeState.jobs.length===0">
    No jobs currently running
    </label>
      <b-list-group-item v-for="item of storeState.jobs" v-bind:key="item.Id">
        <div class="nobreak">
          <v-icon v-if="item.State == 0" name="sync" scale="1"/>
          <v-icon v-if="item.State == 1" name="sync" scale="1" spin/>
          <v-icon v-if="item.State == 2" name="check" scale="1" class="green" />
          <v-icon v-if="item.State == 3" name="cross" scale="1" class="red" />
          <v-icon v-if="item.State == 4" name="ban" scale="1" class="orange" />
          <span>  {{item.Name}}</span>
        </div>
        <span v-if="item.Reason != ''" v-bind:class="{ red: item.State == 3, orange: item.State == 4 }">{{item.Reason}}</span>
      </b-list-group-item>
    </b-list-group>
    </div>

  </div>
</template>

<script lang="ts">
import Vue from 'vue';
import jobsStore from '@/code/JobsStore';

export default Vue.extend({
  name: 'Jobs',
  mounted() {
    this.$root.$on('testttt', (msg: string) => {
      console.log(msg);
    });
  },
  computed: {
    storeState() {
      return jobsStore.state;
    },
  },
  methods: {
    showJobs(showFlag: boolean) {
      this.show = showFlag;
      console.log(this.show);
    },
  },
  data() {
    return {
      show: false,
    };
  },
});
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
  @import "../../src/assets/scss/components/jobs.scss";
</style>
