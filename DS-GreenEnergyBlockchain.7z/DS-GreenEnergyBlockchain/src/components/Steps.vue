<template>
<div class ="steps-container">
<div class="steps-container-hexogen">
<span class="step-container-number">{{stepsNumber}}</span>
</div>
<div class="steps-block">
<span class="steps-container-step-text">{{stepText}}</span>
<span class="steps-container-step-title">{{stepTitle}}</span>
<span class="steps-container-step-description">{{stepDescription}}</span>
</div>
</div> 
</template>

<script lang="ts">
import Vue from 'vue';
export default Vue.extend({
  name: 'Steps',
  props: {
            stepsNumber: {
                type: String,
                required: true,
            },
            stepText: {
                type: String,
                required: true,
            },
            stepTitle: {
                type: String,
                required: true,
            },
            stepDescription: {
                type: String,
                required: true,
            },
        },
});
</script>

<style lang='scss' scoped>
@import '../../src/assets/scss/components/steps.scss'; 
</style>