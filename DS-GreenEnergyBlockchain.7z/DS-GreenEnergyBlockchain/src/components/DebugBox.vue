<template>
  <div>
    <div v-if="show" class="bottomDiv">
      <h3>DebugBox:</h3>
      <b-form-textarea
          id="debugBox"
          placeholder="Debug Txt"
          :rows="3"
          :max-rows="6"
          v-model="debugTxt">
      </b-form-textarea>
    </div>
    <b-button class="botRight" size="lg" variant="primary" v-on:click="show = !show">
      <span v-if="show">Collapse</span>
      <span v-else>Show Debug Box</span>
    </b-button>
  </div>
</template>

<script lang="ts">
import Vue from 'vue';

export default Vue.extend({
  name: 'DebugBox',
  mounted() {
    this.$root.$on('debugMsg', (msg: string) => {
      console.log(msg);
      this.debugTxt = `${msg}\n${this.debugTxt}`;
    });
    this.$root.$on('openDebugBox', () => {
      this.show = true;
    });
  },
  data() {
    return {
      debugTxt: '',
      show: false,
    };
  },
});
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.bottomDiv {
  position: fixed;
  width: 100%;
  bottom: 0;
  left: 0;
  height: 200px;
}

.botRight {
  position: fixed;
  bottom: 0;
  right: 0;
  width: 250px;
}

#debugBox {
  height: 100%;
}
</style>
