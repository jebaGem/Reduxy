#Logs
This folder will contain all the logfiles created by Winston