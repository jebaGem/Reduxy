'use strict';
/**
 * CONFIG --- ACCEPTANCE
 */
module.exports = {

}