'use strict';
/**
 * CONFIG --- TEST
 */
module.exports = {

}