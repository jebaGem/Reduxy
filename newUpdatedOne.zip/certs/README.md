#Certificates
Use this directory to store any SSL-certificates if applicable
Use only if this is a requirement in the case, otherwise just use HTTP
