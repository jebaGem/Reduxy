import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FrontMenJokesComponent } from './front-men-jokes.component';

import { JokesServiceService } from '../jokes-service.service';
import { HttpClient } from '@angular/common/http';
// Import ngx-cache-layer
import {CacheModule} from 'ngx-cache-layer';
import { JokeProvider } from './JokeProvider';

// Define global configuration
// You can set localStorage to true it will cache every layers like a localStorage item
// By default localStorage is set to false
export const CACHE_DI_CONFIG = <any>{
    localStorage: true,
    maxAge: 15 * 60 * 1000, // Items added to this cache expire after 15 minutes
    cacheFlushInterval: 60 * 60 * 1000, // This cache will clear itself every hour
    deleteOnExpire: 'aggressive' // Items will be deleted from this cache when they expire
};

@NgModule({
  imports: [
    CommonModule,
    CacheModule.forRoot(),
    // Import CacheModule with CACHE_DI_CONFIG;
    CacheModule.forRoot(CACHE_DI_CONFIG)
  ],
  declarations: [FrontMenJokesComponent],
  providers: [ JokesServiceService, HttpClient, JokeProvider],
  exports: [FrontMenJokesComponent],
  entryComponents: [FrontMenJokesComponent]
})
export class FrontMenJokesModule { }
