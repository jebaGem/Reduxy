export interface Joke {
    id: string;
    joke: string;
    categories: Array<string>;
  }
  export interface JokeResponse {
    type: string;
    value: Array<Joke>;
  }
