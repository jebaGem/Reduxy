import { Component, OnInit } from '@angular/core';
import { JokesServiceService } from '../jokes-service.service';
import { Observable } from 'rxjs/Observable';
import { Joke } from './font-men-jokes';
import { CacheLayer, CacheLayerItem, CacheService } from 'ngx-cache-layer';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subscription } from 'rxjs/Subscription';
import { JokeProvider } from './JokeProvider';
export interface Item {
  name: string;
}

export const EXAMPLE_CACHE_LAYER_NAME = 'example-layer';
@Component({
  selector: 'app-front-men-jokes',
  templateUrl: './front-men-jokes.component.html',
  styleUrls: ['./front-men-jokes.component.scss']
})
export class FrontMenJokesComponent implements OnInit {
  jokes$: Observable<Array<Joke>>;
  private data;
  cartItems: BehaviorSubject<CacheLayerItem<Joke>[]>;
  cacheLayer: CacheLayer<CacheLayerItem<Joke>>;
  fav: boolean;
  constructor(private service: JokesServiceService,
    private cacheService: CacheService,
    private listProvider: JokeProvider
 ) {
    this.initialSetup(10);
 }

 initialSetup(count: number) {
  this.service.jokesPerCount(count);
  this.jokes$ = this.service.jokes;
  this.jokes$.subscribe((data) => {
    this.data = data;
    this.data.forEach(jokes => {
      this.listProvider.PutToList(jokes);
    });
  }
  );
 }

  ngOnInit() {
  }
  removeItem(product: Joke) {
    console.log(2);
    this.listProvider.removeFromList(product);
  }

  updateItem(product: Joke) {
    this.listProvider.PutToList(product);
  }
  refresh() {
    this.initialSetup(1);
  }
  toggleButton(toggle: boolean, list) {
    this.fav = toggle;
if (this.fav) {
this.updateItem(list);
}else {
this.removeItem(list);
}
  }
}
