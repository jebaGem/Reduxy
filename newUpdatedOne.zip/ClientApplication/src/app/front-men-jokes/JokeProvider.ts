import {Injectable} from '@angular/core';
import {CacheService, CacheLayer, CacheLayerItem, CacheServiceConfigInterface, CacheLayerInterface} from 'ngx-cache-layer';
import { Joke } from './font-men-jokes';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';


export const CART_CACHE_LAYER_NAME = 'cart';



@Injectable()
export class JokeProvider {

  cacheLayer: CacheLayer<CacheLayerItem<Joke>>;
  items: BehaviorSubject<CacheLayerItem<Joke>[]>;

  constructor(private cacheService: CacheService) {
    this.cacheLayer = this.cacheService.createLayer<Joke>(<CacheLayerInterface>{
      name: CART_CACHE_LAYER_NAME,
      config: <CacheServiceConfigInterface>{
        localStorage: true,
        maxAge: 10000,
        cacheFlushInterval: 10000,
        deleteOnExpire: 'aggressive'
      }
    });
    this.items = this.cacheLayer.items;
  }

  PutToList(jokes: Joke) {
    this.cacheLayer.putItem({
      key: jokes.id,
      data: jokes
    });
  }

  removeFromList(jokes: Joke) {
    this.cacheLayer.removeItem(jokes.id);
  }

}
