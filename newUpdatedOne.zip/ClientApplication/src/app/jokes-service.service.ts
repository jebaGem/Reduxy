import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { catchError, map, mergeMap, shareReplay, switchMap } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { timer } from 'rxjs/observable/timer';
import { Joke } from './front-men-jokes/font-men-jokes';
import 'rxjs/add/operator/timeInterval';
import { Observer } from 'rxjs/Observer';
@Injectable()
export class JokesServiceService {
  private _jokes: Joke;
  private jokesCache$: Observable<Joke>;
  private _header: { headers: HttpHeaders };
  private listObserver: Observer<Joke[]>;
  private cache$: Observable<Array<Joke>>;
  private _noOfJokes: number;
private url = 'http://localhost:3000/getJokes/';
  constructor(private _http: HttpClient) { }

   jokesPerCount(numberOfJokes: number) {
    this._noOfJokes = numberOfJokes;
  }
  get jokes() {
    console.log(2);
    if (!this.cache$) {
      // Set up timer that ticks every X milliseconds
      const timer$ = timer(0, 50000);

      // For each tick make an http request to fetch new data
      this.cache$ = timer$.pipe(
        switchMap(_ => this.getMyJokes()),
        shareReplay(1)
      );
    }

    return this.cache$;
  }

  private getMyJokes() {
    return this._http.get<any>(this.url + this._noOfJokes).pipe(
      map(response => response.value)
    );
  }
}
